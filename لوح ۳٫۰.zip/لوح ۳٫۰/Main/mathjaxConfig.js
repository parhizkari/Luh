// this config file is for mathjax configurations to be usable also when the output HTML file is saved by the browser ...!

window.MathJax = {
	showProcessingMessages: true,
	//skipStartupTypeset: true, // to prevent rendering mathjax over the "source" div at the beginning!
	showMathMenu: false,
	messageStyle: "none",
	jax: ["input/TeX", "output/SVG"],	//CommonHTML, HTML-CSS, PreviewHTML, SVG, NativeMML, PlainSource
	//preJax: null,
	//postJax: null,
	tex2jax:{
		//preview: [["img",{src: "Main/images/loader0.gif"}]],	//preview: "none",
		inlineMath: [ ["$","$"] ],	// ["$","$"],["\$","\$"],["\(","\)"],["\\(","\\)"]
		displayMath: [ ["$$","$$"] ],
		processEscapes: true,	// for \$ to mean a common dollar sign, not a math delimiter
		//skipTags: ["script","noscript","style","textarea","pre","code","span"],
	},
	TeX: {
		extensions: ["AMSmath.js", "AMSsymbols.js"],
		TagSide: "right",
		TagIndent: ".8em",
		MultLineWidth: "85%",
		equationNumbers: {
			autoNumber: "AMS",							// or, "all"
			formatNumber: function(n){
				return n.replace(/0/g,"۰").replace(/1/g,"۱").replace(/2/g,"۲").replace(/3/g,"۳").replace(/4/g,"۴")
					.replace(/5/g,"۵").replace(/6/g,"۶").replace(/7/g,"۷").replace(/8/g,"۸").replace(/9/g,"۹");
			},
			//formatTag: function (n) {return '('+n+')'},
			//formatID: function {return 'mjx-eqn-'+String(n).replace(/s/g,"_")},	// tells MathJax what ID to use as an anchor for the equation (so that it can be used in URL references).
			//formatURL: function (id,base) {return base+'#'+encodeURIComponent(id)},	// takes an equation ID and base URL and returns the URL to link to it.
			//useLabelIds: true,	// controls whether element ID’s use the \label name or the equation number
		}
	},
	SVG: {
		mtextFontInherit: true,	// required to correctly render RTL Persian text inside a formula
		linebreaks: { automatic: true}
	},
	"HTML-CSS": {
		mtextFontInherit: true,	// required to correctly render RTL Persian text inside a formula
		//webfont: "STIX-Web",
		//preferredFont: null,	// "Latin-Modern"
		//availableFonts: ["Latin-Modern","TeX"],
		//undefinedFamily: "Niloofar",
		linebreaks: { automatic: true },
		noReflows: false,
	},
	/*unicode: {
		fonts: "'Niloofar','Sols'"  // the default font list for unknown characters
	},*/
};
