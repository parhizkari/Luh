var source=document.getElementById("source"),
	result=document.getElementById("resultMain"),
	resultWrapper=document.getElementById("result");

var	sourceContent=[""], sourceContentString="", resultContent,
	htmlExport, 
	userDefinedCSS="",
	currentItem=0, allItems,
	perPageItems, cumulativeInPageItems,
	currentPage=0, totalPageNumber=1,
	pageBackgrounds={},
	RTLVar=1, PresentationVar=0;
	
	
var ftnNum=0, refFTN=0, figNum=0, videoNum=0, audioNum=0, iFrameNum=0, tblNum=0,
	itemNum=0, pageNum=0, pageNumVar=0,
	presentationToPrevPage=0;
var nestedListLevel=0;
	

document.getElementById("goToPage").value="۱ \/ ۱";
document.getElementById("goToPage-B").value="۱ \/ ۱";

document.getElementById("resultFooter").style.display='none';


// -----------------------------------------------------------------------------
// to use localStorage of HTML5 for saving the "source" div on the fly, if the browser/tab is closed data will remain saved until the browser's cache is deleted ... 

if (window.localStorage["TextEditorData"]){  // retrieves the source code from the browser's cache even after the browser/tab is reopened
	sourceContentString=window.localStorage["TextEditorData"];
	sourceContent = sourceContentString.split(" <NEWPAGE> ");
	totalPageNumber = sourceContent.length;
	currentPage = 0;
	changePage();
}
var inactivityPeriod;
source.addEventListener("keyup", function() {
	//console.log('Textarea Change');
	clearTimeout(inactivityPeriod);			// resets "inactivityPeriod" because a change has been captured
	inactivityPeriod = setTimeout(function() {	// Runs 1s (1000 ms) after the last change
		sourceContent[currentPage]=source.value;
		sourceContentString=sourceContent.join(" <NEWPAGE> ");
		
		window.localStorage["TextEditorData"] = sourceContentString;	// stores the source code after 1 s pause after each keyup
		setTimeout(function() {
			document.getElementById('save-log').style.display = 'inline-block';	// Runs 1s (1000 ms) after the last change
		}, 1000);
		setTimeout(function() {
			document.getElementById('save-log').style.display = 'none';		// Runs 1s (1000 ms) after the last change
		}, 2000);
	}, 1000);
});



// -----------------------------------------------------------------------------
// for finding the present date in Persian Calendar

function gregorian_to_jalali(gy,gm,gd){
	g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
	jy=(gy<=1600)?0:979;
	gy-=(gy<=1600)?621:1600;
	gy2=(gm>2)?(gy+1):gy;
	days=(365*gy) +(parseInt((gy2+3)/4)) -(parseInt((gy2+99)/100)) +(parseInt((gy2+399)/400)) -80 +gd +g_d_m[gm-1];
	jy+=33*(parseInt(days/12053)); 
	days%=12053;
	jy+=4*(parseInt(days/1461));
	days%=1461;
	jy+=parseInt((days-1)/365);
 	if(days > 365)days=(days-1)%365;
	jm=(days < 186)?1+parseInt(days/31):7+parseInt((days-186)/30);
	jd=1+((days < 186)?(days%31):((days-186)%30));
	return [jy,jm,jd];
};
var persianMonth=["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
var dayOfWeek=["یکشنبه","دوشنبه","سه‌شنبه", "چهارشنبه","پنجشنبه","جمعه","شنبه"];
var shortDate;
function persianDateTime(){
	d=new Date();
	g_y=d.getFullYear();
	g_m=d.getMonth()+1;
	g_d=d.getDate();
	var currenDayOfWeek=d.getDay();
	shamsi=gregorian_to_jalali(g_y,g_m,g_d);
	
	H = d.getHours();
	i = d.getMinutes();
	i = (i<10) ? "0"+i : i;
	
	var morningAfternoon= 
		(H==12)  ? "ظهر" : (
			(H!=0) ? (
				(H<12) ? "صبح" : (
					(H>=20) ? "شب" :  "بعد از ظهر"
				)
			)
			: "نیمه‌شب"
		);
	shortDate=shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" - "+H+":"+i;
	
	H = (H<=12)  ?  H  :  H-12;
	H = (H<10) ? "0"+H : H;
	
	//return shamsi[0]+"-"+persianMonth[shamsi[1]]+"-"+shamsi[2]+"("+H+" "+i+")";
	return dayOfWeek[currenDayOfWeek]+" "+ shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+"، ساعت "+H+":"+i+" "+morningAfternoon;	// "نسخه‌ی "+shamsi[2]+" "+persianMonth[shamsi[1]]+" "+shamsi[0]+" ساعت "+H+" و "+i+" دقیقه‌ی "+morningAfternoon;
};
// now you can use the present date by calling the function  persianDateTime()




//=================  TRANSFORM NUMBERS TO PERSIAN/ENGLISH  ==================



function toFa(textContainingEnglishNumbers){
	return textContainingEnglishNumbers.toString()
		.replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴').replace(/5/g,'۵')
		.replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹').replace(/\./g,'/');
}
function toEn(persianNumbers){
	return Number(
		persianNumbers.toString()
			.replace(/۰/g,'0').replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3').replace(/۴/g,'4').replace(/۵/g,'5')
			.replace(/۶/g,'6').replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9').replace(/\//g,'.')
	);
}
//alert(toFa("53 is 53 and not 78 !"));
//alert(toEn("۴۵")+2);
var abjad="الف ب ج د هـ و ز ح ط ی ک ل م ن س ع ف ص ق ر ش ت ث خ ذ ض ظ غ".split(" "),
		Roman="I II III IV V VI VII VIII IX X XI XII XIII XIV XV".split(" "),
		roman="i ii iii iv v vi vii viii ix x xi xii xiii xiv xv".split(" ");
//var dice=["⚀","⚁","⚂","⚃","⚄","⚅","⚅⚀","⚅⚁","⚅⚂","⚅⚃","⚅⚄","⚅⚅"];		//["◌","○","◷","◶","◵","◴","□","◳","◲","◱","◰","◓","◑","◒","◐","●","◨","◪","◧","◩","■"];




// -----------------------------------------------------------------------------
// to define some static keyboard shortcuts and etc ...

document.addEventListener("keydown", function(e){
	if (e.shiftKey && e.keyCode === 13) {
		e.preventDefault();
		source.selectionStart = source.selectionEnd;	// to deselect text, not to delete any text, buggy action to be hacked
// اگر سریع قبل از ذخیره شدن در cache اجرا کنم مطلبی که در cache ذخیره شده است را کامپایل می‌کند و اضافه شده‌ها را حذف می‌کند!!
		compile();
	}
	
	
	// add the shortcut "ctrl + F5" for toggling between the "Presentation Mode" and back
	if (e.ctrlKey && e.keyCode === 116) {
		e.preventDefault();
		//var chb=document.getElementById("presentationModeChb");
		presentation();
	}
	
	// add the shortcut "ctrl + F1" for ADD A NEW PAGE
	if (e.ctrlKey && e.keyCode === 112) { e.preventDefault(); addNewPage(); }
	// add the shortcut "ctrl + F2" to REMOVE CURRENT PAGE
	if (e.ctrlKey && e.keyCode === 113) { e.preventDefault(); removePage(); }
	// add the shortcut "ctrl + F3" to JUMP TO PAGE
	if (e.ctrlKey && e.keyCode === 114) {
		e.preventDefault();
		var pn = toEn(prompt("به کدام صفحه بپرم؟", "۱").replace(/[^\d۰۱۲۳۴۵۶۷۸۹]/g,""));
		if(!(Number.isInteger(pn))){
			alert("برای شماره‌ی صفحه باید عدد وارد نمایید ...");
			return false;
		}
		currentPage=(pn)-1;
		(currentPage < 0) ? currentPage=0 : 0;
		(currentPage > totalPageNumber-1) ? currentPage=totalPageNumber-1 : 0;
		changePage();
	}
	
	// add the shortcut "ctrl+down" for page change to NEXT
	if (e.ctrlKey && e.keyCode === 40) { e.preventDefault(); nextPage(); }
	// add the shortcut "ctrl+up" for page change to PREVIOUS
	if (e.ctrlKey && e.keyCode === 38) { e.preventDefault(); prevPage(); }
	
	
	/*// these shortcuts should be added and removed dynamically ...
	//
	// add the shortcut "ctrl+right" for Previous Item in the PRESENTATION mode
	if (e.ctrlKey && e.keyCode === 39) { e.preventDefault(); prevItem(); }
	// add the shortcut "ctrl+left" for Next Item in the PRESENTATION mode
	if (e.ctrlKey && e.keyCode === 37) { e.preventDefault(); nextItem(); }
	*/
	
	
	// to close the Popups by pressing the key "Esc"
	if (e.keyCode === 27) { window.location.href='#'; }
});

// to close the Popups by clicking outside the Popups ...
document.onclick = function(e){
	//check if the dark backgrounds of the popups are clicked ...
	if(e.target.id == 'popupSmilies' || e.target.id == 'popupGuide' || e.target.id == 'popupAbout'){
		window.location.href='#';
	}
}




// -----------------------------------------------------------------------------
// Pagination


function addNewPage(){
	var n = prompt("بعد از صفحه‌ی حاضر چند صفحه اضافه شود؟ (یک عدد صحیح وارد نمایید)", "۱").replace(/[^\d۰۱۲۳۴۵۶۷۸۹]/g,"");
	n=(n)? toEn(n) : "0";
	
	var localCounter=n;
	if(n>0){
		while(localCounter>0){
			sourceContent.splice(currentPage+1,0,"");
			localCounter--;
		}
		currentPage++;
		totalPageNumber+=n;
		changePage();
	}
}
function removePage(){
	if(totalPageNumber==1){
		alert("حداقل تعداد صفحات ۱ می‌باشد!");
		return false;
	}
	if(!confirm('با ادامه‌ی این کار، صفحه‌ی حاضر با شماره‌ی «'+toFa(currentPage+1)+'» حذف میشود، آیا با این حال ادامه می‌دهید؟')){
		return false;
	}
	sourceContent.splice(currentPage,1);
	totalPageNumber--;
	(currentPage > 0) ? currentPage-- : currentPage=0 ;
	changePage();
}
function nextPage(){
	(currentPage < totalPageNumber-1) ? currentPage++ : currentPage=totalPageNumber-1 ;
	changePage();
}
function prevPage(){
	(currentPage > 0) ? currentPage-- : currentPage=0 ;
	changePage();
}
document.getElementById("goToPage").onkeypress = function(ev){
	if (ev.which === 13){
		var pn=toEn(document.getElementById("goToPage").value);
		if(!(Number.isInteger(pn))){
			alert("برای شماره‌ی صفحه باید عدد وارد نمایید ...");
			currentPage=0;
			changePage();
			return "";
		}
		currentPage=(pn)-1;
		(currentPage < 0) ? currentPage=0 : 0;
		(currentPage > totalPageNumber-1) ? currentPage=totalPageNumber-1 : 0;
		changePage();
	}
}
document.getElementById("goToPage-B").onkeypress = function(ev){
	if (ev.which === 13){
		var pn=toEn(document.getElementById("goToPage-B").value);
		if(!(Number.isInteger(pn))){
			alert("برای شماره‌ی صفحه باید عدد وارد نمایید ...");
			currentPage=0;
			changePage();
			return "";
		}
		currentPage=(pn)-1;
		(currentPage < 0) ? currentPage=0 : 0;
		(currentPage > totalPageNumber-1) ? currentPage=totalPageNumber-1 : 0;
		changePage();
	}
}



document.getElementById("goToPage").onclick = function(){
	document.getElementById("goToPage").value="";
}
document.getElementById("goToPage-B").onclick = function(){
	document.getElementById("goToPage-B").value="";
}
document.getElementById("goToPage").addEventListener("focusout",function(){
	document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage+1);
});
document.getElementById("goToPage-B").addEventListener("focusout",function(){
	document.getElementById("goToPage-B").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage+1);
});



function changePage(){
	document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage+1);
	document.getElementById("goToPage-B").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage+1);
	source.value=sourceContent[currentPage];
	
	for(var i=0; i<totalPageNumber; i++){
		if(document.getElementById("resultPage-"+i) &&
		   !document.getElementById("resultPage-"+i).classList.contains("hidden")) {
				document.getElementById("resultPage-"+i).classList.add("hidden");
		}
	}
	if(document.getElementById("resultPage-"+currentPage)){
		document.getElementById("resultPage-"+currentPage).classList.remove("hidden");
	}
	
	
	
	if(PresentationVar){
		// show the footer containing the page number and navigation tool
		document.getElementById("resultFooter").style.display='inline-block';
		
		// hide all the footnote sections at the end of pages
		[].map.call(document.querySelectorAll('*[id^="ftnOnPage-"]'), function(el) {
			el.style.display="none";
		});
		
		// set the correct item number as the current item, and scroll to it, either on top or bottom of the page
		if(currentPage==0){
			if(presentationToPrevPage==0){
				currentItem = 0;
				//alert(currentItem);
				result.scrollTop = 0;
			}else{
				currentItem = Number(cumulativeInPageItems[0]) - 1;
				//alert(currentItem);
				result.scrollTop = result.scrollHeight - result.clientHeight;
			}
		}else{
			if(presentationToPrevPage==0){
				currentItem = cumulativeInPageItems[currentPage-1];	// no worry, each new page contains at least ONE item
				//alert(currentItem);
				result.scrollTop = 0;
			}else{
				currentItem = Number(cumulativeInPageItems[currentPage]) - 1;
				//alert(currentItem);
				result.scrollTop = result.scrollHeight - result.clientHeight;
			}
		}
		
		var itemsList = document.querySelectorAll('*[id^="item-"]');
		// Now show all the items before the current item
		for(var i=0; i<=currentItem; i++){
			if(itemsList[i].classList.contains("hidden")){
				itemsList[i].classList.remove("hidden");
				itemsList[i].classList.add("active");
			}
		}
		// Then show all the items before the current item
		for(var i=currentItem+1, l=itemsList.length; i<l; i++){
			if(!itemsList[i].classList.contains("hidden")){
				itemsList[i].classList.add("hidden");
				itemsList[i].classList.remove("active");
			}
		}
		
		// to enable temporarily appearing Canvas overlayer for freehand drawing becoming avaiable by Ctrl+mouseevent
		draw();
	}
	
	// to set the right background for the page if the user have defined any ...
	if(pageBackgrounds[currentPage] != undefined){
		result.style.background = pageBackgrounds[currentPage];
	}else{
		result.style.background = "rgb(245, 222, 179) url(Main/images/BG.png) repeat";
	}
	
	source.focus();
}




// -----------------------------------------------------------------------------
// to refresh the document -> New Document

function refreshDoc(){
	if(localStorage.getItem("TextEditorData") !== null && JSON.stringify(localStorage["TextEditorData"]).replace(/\"\"/g,"") != ""){
		if(!confirm('با تازه‌کردن صفحه، اطلاعات ذخیره‌نشده‌ی پروژه‌ی حاضر از دست می‌رود، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	sourceContent=[""]; sourceContentString=""; result.innerHTML=""; //window.localStorage["TextEditorData"] = "";
	currentItem=0; currentPage=0; totalPageNumber=1;
	document.getElementById("fileName").innerHTML="هنوز هیچ فایلی بارگذاری نشده است ...!"
	
	changePage();
}



// -----------------------------------------------------------------------------
// Presentation Navigation within each page


var handler = function(e){
	// add the shortcut "ctrl+right" for Previous Item in the PRESENTATION mode
	if (e.ctrlKey && e.keyCode === 39) { e.preventDefault(); prevItem(); }
	// add the shortcut "ctrl+left" for Next Item in the PRESENTATION mode
	if (e.ctrlKey && e.keyCode === 37) { e.preventDefault(); nextItem(); }
}
function nextItem(){
	currentItem++;
	if(currentItem == allItems.length){
		currentItem--;	// currentItem has reached its upper limit in th whole document and no action should take place!
		return false;
	}
	for(var pageNum=0; pageNum<totalPageNumber-1; pageNum++){
		if(currentItem == cumulativeInPageItems[pageNum]){
			currentPage=pageNum+1;
			changePage();
			return false;
			//break;	// note that the first item in each page is by default un-hidden, so no need to unhide it again!
		}
	}
	
	
	var el=document.getElementById("item-"+currentItem);
	el.classList.remove("hidden");
	el.classList.add("active");
	el.scrollIntoView({behavior: "smooth", block: "center", inline: "nearest"});	// or use inline: "center"
	
	
	// to add the typing effect (text appearing character by character like it is typed right the time)
	var elem=el.getElementsByClassName("typingEffect")[0],	// so each item can contain only 1 typing effect!
		txt=elem.innerHTML,
		speed=Number(elem.getAttribute("speed")),
		charCounter=0;
		//s=0, e=0;
	elem.innerHTML="";
	typeWriter();
	// now type the innerHTML of the element by a "nested" setTimeout
	function typeWriter() {
		if (charCounter < txt.length) {
			if(txt.charAt(charCounter)=='\<'){
				while(txt.charAt(charCounter-1)!='\>'){charCounter++;}
			}else if(txt.charAt(charCounter)=='«'){		// anything wrapped in «...» will be jumped over.
				//s=charCounter;
				while(txt.charAt(charCounter-1)!='»'){charCounter++;}
				//e=charCounter;
				//charCounter=s;
			}
			elem.innerHTML=txt.slice(0, charCounter+1);
			charCounter++;
			//if(charCounter<e) setTimeout(typeWriter, speed/15);
			/*else*/ setTimeout(typeWriter, speed);
		}
	}
}
function prevItem(){
	if(currentItem == 0){
		return false;	// the 0th item, which resides in the 0th page, should always be shown
	}
	for(var pageNum=0; pageNum<totalPageNumber-1; pageNum++){
		if(currentItem == cumulativeInPageItems[pageNum]){
			currentPage=pageNum;
			presentationToPrevPage=1;
			changePage();
			presentationToPrevPage=0
			return false;
			//break;		// not hiding the first item in each page, anyway
		}
	}
	document.getElementById("item-"+currentItem).classList.add("hidden");
	document.getElementById("item-"+currentItem).classList.remove("active");
	currentItem--;
	
	document.getElementById("item-"+currentItem).scrollIntoView({behavior: "smooth", block: "center", inline: "nearest"});	// or use inline: "center"
}
function presentation(){
	if(result.innerHTML==""){
		if(!PresentationVar){ alert("برای رفتن به حالت «ارائه»، خروجی نباید خالی باشد، لطفاً ابتدا ورودی خود را کامپایل نمایید!"); }
		return false;
	}
	PresentationVar=(PresentationVar)? 0 : 1 ;
	
	if(PresentationVar){
		document.getElementById("presentation").src="Main/images/main.png";
		document.getElementById("presentationB").src="Main/images/main.png";
		document.getElementById("presentation").title="برای خروج از حالت ارائه فشار دهید (کنترل + f5)";
		document.getElementById("presentationB").title="برای خروج از حالت ارائه فشار دهید (کنترل + f5)";
		
		document.getElementById("resultFooter").style.display='initial';
		
		document.getElementById("btn_prev_item").style.display='inline-block';
		document.getElementById("btn_prev_itemB").style.display='inline-block';
		document.getElementById("btn_next_item").style.display='inline-block';
		document.getElementById("btn_next_itemB").style.display='inline-block';
		// to add keyboard shortcuts
		document.addEventListener("keydown", handler);
		
		
		// open the result div in FullScreen
		var requestMethod = resultWrapper.requestFullScreen
				|| resultWrapper.webkitRequestFullScreen
				|| resultWrapper.mozRequestFullScreen
				|| resultWrapper.msRequestFullScreen;
		requestMethod.call(resultWrapper);
	    
	        
		// first hide all the footnote sections at the end of pages
		[].map.call(document.querySelectorAll('*[id^="ftnOnPage-"]'), function(el) {
			el.style.display="none";
		});
		// then hide all the items
		[].map.call(document.querySelectorAll('*[id^="item-"]'), function(el) {
			if(!el.classList.contains("hidden")){
				el.classList.add('hidden');
				el.classList.remove("active");
			}
			el.classList.add('hover');
		});
		// set the proper value to currentItem, according to currentPage
		if(currentPage==0){
			currentItem = 0;
		}else{
			currentItem = cumulativeInPageItems[currentPage-1];	// no worry, each new page contains at least ONE item
		}
		// to, by default, undo-hide some specific items, e.g. that by which the currentPage begins ...
		document.getElementById("item-"+currentItem).classList.remove("hidden");
		document.getElementById("item-"+currentItem).classList.add("active");
		
		
		// to enable temporarily appearing Canvas overlayer for freehand drawing becoming avaiable by Ctrl+mouseevent
		draw();
		
	}else{
		document.getElementById("presentation").src="Main/images/presentation.png";
		document.getElementById("presentationB").src="Main/images/presentation.png";
		document.getElementById("presentation").title="برای رفتن به حالت ارائه فشار دهید (کنترل + f5)";
		document.getElementById("presentationB").title="برای رفتن به حالت ارائه فشار دهید (کنترل + f5)";
		
		document.getElementById("resultFooter").style.display='none';
		
		document.getElementById("btn_prev_item").style.display='none';
		document.getElementById("btn_prev_itemB").style.display='none';
		document.getElementById("btn_next_item").style.display='none';
		document.getElementById("btn_next_itemB").style.display='none';
		
		// to remove keyboard shortcuts
		document.removeEventListener("keydown", handler);
		
		/*
		// revert back the "result" from being shown in FullScreen, if so
		if(document.fullscreenElement
			|| document.webkitFullscreenElement
			|| document.mozFullScreenElement
			|| document.msFullscreenElement
		){
			var requestMethod = resultWrapper.exitFullscreen
					|| resultWrapper.webkitExitFullscreen
					|| resultWrapper.mozCancelFullScreen
					|| resultWrapper.msExitFullscreen;
	        	requestMethod.call(resultWrapper);
		}
		*/
		
		
	    // unhide all the footnote sections at the end of pages
		[].map.call(document.querySelectorAll('*[id^="ftnOnPage-"]'), function(el) {
			if(document.getElementById("ftnColWrapperOnPage-"+el.id.replace(/ftnOnPage-/,"")).innerHTML != ""){
				el.style.display="initial";
			}
		});
		// unhide all the items
		[].map.call(document.querySelectorAll('*[id^="item-"]'), function(el) {
			if(el.classList.contains("hidden")){
				el.classList.remove('hidden');
				el.classList.add("active");
			}
			el.classList.remove('hover');
		});
	}
}
// to enable temporarily appearing Canvas overlayer (while in Presentation) for freehand drawing becoming avaiable by Ctrl+mouseevent
function draw(){
	var canvas = document.getElementById('canvas');
	var ctx = canvas.getContext('2d');
	resize();
	function resize() {			// resize canvas
		ctx.canvas.width = window.innerWidth;
		ctx.canvas.height = window.innerHeight;
	}
	
	// define mouse events
	window.addEventListener('resize', resize);
	document.addEventListener('mousemove', drawIt);
	document.addEventListener('mousedown', setPosition);
	document.addEventListener('mouseenter', setPosition);
	
	// track the current [not by an array] mouse curser's position
	var pos = {x:0, y:0};
	// update position from mouse event
	function setPosition(e) {
		if (e.buttons !== 1 || !e.ctrlKey) return false;	// "Ctrl key" & "mouse left button" must be pressed together
		e.stopPropagation(); // for some browsers stop redirecting
		e.preventDefault();
		
		canvas.style.zIndex = '3';
		
		pos.x = e.clientX;
		pos.y = e.clientY;
	}
	
	// freehand drawing
	function drawIt(e) {
		if (e.buttons !== 1 || !e.ctrlKey) return false;	// "Ctrl key" & "mouse left button" must be pressed together
		e.stopPropagation(); // for some browsers stop redirecting
		e.preventDefault();
		
		canvas.style.zIndex = '3';
		
		ctx.beginPath(); // begin
		
		ctx.lineWidth = 3;
		ctx.strokeStyle = 'rgba(220,20,60,0.75)';
		ctx.lineCap = 'round';
		ctx.lineJoin = 'round';
		
		ctx.moveTo(pos.x, pos.y); // from
		setPosition(e);
		ctx.lineTo(pos.x, pos.y); // to
		ctx.stroke(); // draw it!
	}
	// clear drawing on right click
	canvas.oncontextmenu = function() {		// i.e. if rightClick is pressed on the canvas overlayer
		ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);	// clear the canvas, so next time canvas is empty
		canvas.style.zIndex = '-1';			// hide canvas for links to again become clickable, texts selectable & ...
		return false; 
	}
}


// -----------------------------------------------------------------------------
// now we provide the compile() function to compile the source code and produce the result

// now define the action of the compile button
function compile(){
	//document.getElementById("presentationModeChb").checked= false;	// source is always compiled into non_Presentation Mode
	PresentationVar=0;
	document.getElementById("resultFooter").style.display='none';
	document.getElementById("btn_next_item").style.display='none';
	document.getElementById("btn_prev_item").style.display='none';
	
	document.getElementById("presentation").src="Main/images/presentation.png";
	document.getElementById("presentationB").src="Main/images/presentation.png";
	document.getElementById("presentation").title="برای رفتن به حالت ارائه فشار دهید (کنترل + f5)";
	document.getElementById("presentationB").title="برای رفتن به حالت ارائه فشار دهید (کنترل + f5)";
	
	sourceContent[currentPage]=source.value;
	sourceContentString=sourceContent.join(" <NEWPAGE> ");
	
	userDefinedCSS="";
	refHeader=0; ftnNum=0; refFTN=0; figNum=0; videoNum=0; audioNum=0; iFrameNum=0; tblNum=0; itemNum=0; pageNum=0; pageNumVar=0;
	nestedListLevel=0;
	//var H1MaxHeight=0, H2MaxHeight=0, H3MaxHeight=0;
	
	resultContent="<div id='resultPage-0'><div class='item active' onPage='0'></div>"
		+sourceContentString
			// to place each page inside a div, one being shown at a time others being hidden
			//.replace(/(?:\<NEWPAGE\>)[\s]*(?:\/زمینه\{([^\}]*)\})?/g, function(x,y){	// دستور /زمینه{...} برای دادن آدرس یک عکس به عنوان پشت‌زمینه‌ی اسلایدهاست
			.replace(/(\<NEWPAGE\>)/g, function(x,y){
				pageNum++;
				//var bg = (y!=undefined)? "style='background: url("+y+") repeat; padding:0; margin:0;'" : "";
				return 	"<div id='ftnOnPage-"+(pageNum-1)+"' style='display:none;'>"
							+"<br><hr style='width:30%; float:right;'><div style='margin:20px;'></div>"
							+"<div id='ftnColWrapperOnPage-"+(pageNum-1)+"'></div>"
						+"</div>"
						+"</div>"								// to close the previous page
						+"<div id='resultPage-"+pageNum+"'>"	// یا "<div id='resultPage-"+pageNum+"' "+bg+">"
							+"<div class='item active' onPage='"+(pageNum-1)+"'></div>";
			});
			
			
			
	result.innerHTML=resultContent
				+"<div id='ftnOnPage-"+pageNum+"' style='display:none;'>"
					+"<br><hr style='width:30%; float:right;'><div style='margin:20px;'></div>"
					+"<div id='ftnColWrapperOnPage-"+pageNum+"'></div>"
				+"</div>"
			+"</div>";
	
	//alert(result.innerHTML);
	
	pageBackgrounds={}
	
	var pages=result.querySelectorAll('[id^=resultPage-]');
	for(var i=0, len=pages.length; i<len; i++){
		pageNumVar=i;
		var pageContent=pages[i].innerHTML;
		
		// for THISPAGE specification of font, fontSize, lineHeight, fontColor, & BG
			// use it as /ص[ق: قلم][ا: اندازه][ر: رنگ][س: سایه][ف: فاصله‌ی‌بین‌خطوط][پ: پس‌زمینه]
			// although each [] is optional ...	
		pageContent=pageContent.replace(/(?:\/ص)[ \t\n]*(?:\[ق:[ \t\n]*(ف[۱-۹]|f\d)?[ \t\n]*\])?[ \t\n]*(?:\[ا:[ \t\n]*([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)[ \t\n]*\])?[ \t\n]*(?:\[ر:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[س:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[ف:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[پ:[ \t\n]*([\S\s]*?)[ \t\n]*\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				if(y1!=undefined){
					y1=y1.replace(/f/,"en").replace(/ف/,"fa")
						.replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3')
						.replace(/۴/g,'4').replace(/۵/g,'5').replace(/۶/g,'6')
						.replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9');
					switch(y1) {
						case "fa1":
							pages[i].style.fontFamily="en1, fa1";
							break;
						case "fa2":
							pages[i].style.fontFamily="en5, fa2";
							break;
						case "fa3":
							pages[i].style.fontFamily="fa3";
							break;
						case "fa4":
							pages[i].style.fontFamily="en4, fa4";
							break;
						case "fa5":
							pages[i].style.fontFamily="en4, fa5";
							break;
						case "fa6":
							pages[i].style.fontFamily="en2, fa6";
							break;
						case "fa7":
							pages[i].style.fontFamily="en3, fa7";
							break;
						case "fa8":
							pages[i].style.fontFamily="en1, fa8";
							break;
						case "en1":
							pages[i].style.fontFamily="en1";
							break;
						case "en2":
							pages[i].style.fontFamily="en2, fa6";
							break;
						case "en3":
							pages[i].style.fontFamily="en3, fa7";
							break;
						case "en4":
							pages[i].style.fontFamily="en4, fa4";
							break;
						case "en5":
							pages[i].style.fontFamily="en5, fa2";
							break;
						case "en6":
							pages[i].style.fontFamily="en6, fa5";
							break;
						case "en7":
							pages[i].style.fontFamily="en7";
							break;
					}
				}
				if(y2!=undefined){
					pages[i].style.fontSize="calc( 100% *"+toEn(y2.replace(/[\/٫٬]/,"."))+" )";
				}
				if(y3!=undefined){
					pages[i].style.color=y3;
				}
				if(y4!=undefined){
					pages[i].style.textShadow=y4;
				}
				if(y5!=undefined){
					pages[i].style.lineHeight="calc( 100% *"+toEn(y5.replace(/[\/٫٬]/,"."))+" )";
				}
				if(y6!=undefined){
					pageBackgrounds[pageNumVar]=y6;
				}
				return (!y1 && !y2 && !y3 && !y4 && !y5 && !y6)? "/ص" : "";
		})
		pageContent=pageContent.replace(/(\n*\/خ\/\n*)/g,"<br>");
		pageContent=parseStyles(pageContent);
		pageContent=parseTables(pageContent);
		pageContent=parseFigures(pageContent);
		pageContent=parseVideos(pageContent);
		pageContent=parseAudios(pageContent);
		pageContent=parseiFrames(pageContent);
		pageContent=parseReferences(pageContent);
		pageContent=parseFootnotes(pageContent);
		pageContent=parseListItems(pageContent);
		pageContent=parsePresentationItems(pageContent);
		pageContent=parseEnvironments(pageContent);
		pageContent=parseSymbols(pageContent);
		
		
		pageContent=pageContent
			.replace(/(\n{0,1}\\begin\{align\})/g,"\\begin{align}")			// for better vertical spacing
			.replace(/(\n{0,1}\\begin\{equation\})/g,"\\begin{equation}")	// for better vertical spacing
			.replace(/(\\end\{align\})\n{0,1}/g,"\\end{align}")				// for better vertical spacing
			.replace(/(\\end\{equation\})\n{0,1}/g,"\\end{equation}")		// for better vertical spacing
			
			.replace(/\n/g,"<br>")
			//.replace(/(\<hr[^\>]*\>)(\<br\>)+/g,"$1")
			.replace(/(\<\/[ou]l\>)\<br\>/g,"$1")
			;
		
		
		// to take care of lists and nested lists
		while(nestedListLevel){
			pageContent=pageContent
							.replace(/\<\/ol[^\>]*\>(?:\<br\>)?\<ol\>/g,"")
							.replace(/\<\/ul[^\>]*\>(?:\<br\>)?\<ul\>/g,"")
							.replace(/\<\/li\>\<ol\>/g,"\<ol\>")
							.replace(/\<\/li\>\<ul\>/g,"\<ul\>");
			nestedListLevel--;
		}
		
		pages[i].innerHTML=pageContent;
	}
	
	
		
	
	if(document.getElementById("today")){
		document.getElementById("today").innerHTML = toFa(persianDateTime());
	}
	
	
	
	// to handle the header styling, numbering, and generating the Table of Content
	var headers=document.getElementsByClassName("header");
	var h1Num=h2Num=h3Num=0, h4Num=h5Num=h6Num=-1;
	var toc="", tocOnWhichPage;
	if(document.getElementById("toc")){
		toc="<div class='header' id='tocTitle'>فهرست مطالب</div><br>";
		tocOnWhichPage=document.getElementById("toc").getAttribute("onPage");
	}
	for (var i=0, l=headers.length; i<l; i++) {
		var header = headers[i];
		
		if(header.getAttribute("kind")=="h1"){
			h1Num++; h2Num=h3Num=0; h4Num=h5Num=h6Num=-1;
			var h1NumPersian=toFa(h1Num);
			if(document.getElementById("toc")==null){
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"' class='header1Content'>"
							+"<td class='header1Inside1'>"+h1NumPersian+"</div> "
							+"<td class='header1Inside2'>"+header.innerHTML+"</div>"
						+"</tr></table>";
			}else{
				var elementOnWhichPage=header.getAttribute("onPage");
				
				toc+="<table><tr valign=top id='H-"+h1Num+"' class='tocItemsH1 header1Content'>"
						+"<td class='header1Inside1'>"
							+"<a href='#header-"+h1Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
								+h1NumPersian
							+" </a>"
						+"</td>"
						+"<td class='header1Inside2'>"
							+"<a href='#header-"+h1Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
								+header.innerHTML
							+"</a>"
						+"</td>"
					+"</tr></table>";
					
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"' class='header1Content'>"
							+"<td class='header1Inside1'>"
								+"<a href='#H-"+h1Num+"' class='refToTOC' style=\"margin-right: 10px;\" onclick='currentPage="+tocOnWhichPage+"; changePage();'>"
									+h1NumPersian
								+"</a>"
							+"</td> "
							+"<td class='header1Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}
		}else if(header.getAttribute("kind")=="h2"){
			h2Num++; h3Num=0; h4Num=h5Num=h6Num=-1;
			var h2NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num);		// &hairsp; is a hairspace that is used after the "." for "." to remain a "." between two numbers
			if(document.getElementById("toc")==null){
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"' class='header2Content'>"
							+"<td class='header2Inside1'>"+h2NumPersian+"</td> "
							+"<td class='header2Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}else{
				var elementOnWhichPage=header.getAttribute("onPage");
				
				toc+="<table><tr valign=top class='tocItemsH1 header1Content'>"
						+"<td class='header1Inside1'></td>"
						+"<td class='header1Inside2'>"
							+"<table><tr valign=top id='H-"+h1Num+"."+h2Num+"' class='tocItemsH2 header2Content'>"
								+"<td class='header2Inside1'>"
									+"<a href='#header-"+h1Num+"."+h2Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
										+h2NumPersian
									+" </a>"
								+"</td>"
								+"<td class='header2Inside2'>"
									+"<a href='#header-"+h1Num+"."+h2Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
										+header.innerHTML
									+"</a>"
								+"</td>"
							+"</tr></table>"
						+"</td>"
					+"</tr></table>";
					
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"' class='header2Content'>"
							+"<td class='header2Inside1'>"
								+"<a href='#H-"+h1Num+"."+h2Num+"' class='refToTOC' style=\"margin-right: 10px;\" onclick='currentPage="+tocOnWhichPage+"; changePage();'>"
									+h2NumPersian
								+"</a>"
							+"</td> "
							+"<td class='header2Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}
		}else if(header.getAttribute("kind")=="h3"){
			h3Num++; h4Num=h5Num=h6Num=-1;
			var h3NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num);		// &hairsp; is a hairspace that is used after the "." for "." to remain a "." between two numbers
			
			if(document.getElementById("toc")==null){
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"' class='header3Content'>"
							+"<td class='header3Inside1'>"+h3NumPersian+"</td> "
							+"<td class='header3Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}else{
				var elementOnWhichPage=header.getAttribute("onPage");
				
				toc+="<table><tr valign=top class='tocItemsH1 header1Content'>"
						+"<td class='header1Inside1'></td>"
						+"<td class='header1Inside2'>"
							+"<table><tr valign=top class='tocItemsH2 header2Content'>"
								+"<td class='header2Inside1'></td>"
								+"<td class='header2Inside2'>"
									+"<table><tr valign=top id='H-"+h1Num+"."+h2Num+"."+h3Num+"' class='tocItemsH3 header3Content'>"
										+"<td class='header3Inside1'>"
											+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
												+h3NumPersian
											+" </a>"
										+"</td>"
										+"<td class='header3Inside2'>"
											+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
												+header.innerHTML
											+"</a>"
										+"</td>"
									+"</tr></table>"
								+"</td>"
							+"</tr></table>"
						+"</td>"
					+"</tr></table>";
					
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"' class='header3Content'>"
							+"<td class='header3Inside1'>"
								+"<a href='#H-"+h1Num+"."+h2Num+"."+h3Num+"' class='refToTOC' style=\"margin-right: 10px;\" onclick='currentPage="+tocOnWhichPage+"; changePage();'>"
									+h3NumPersian
								+"</a>"
							+"</td> "
							+"<td class='header3Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}
		}else if(header.getAttribute("kind")=="h4"){
			h4Num++; h5Num=h6Num=-1;
			var h4NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num)+".&hairsp;"+abjad[h4Num];
			
			if(document.getElementById("toc")==null){
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"' class='header4Content'>"
							+"<td class='header4Inside1'>"+h4NumPersian+"</td> "
							+"<td class='header4Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}else{
				var elementOnWhichPage=header.getAttribute("onPage");
				
				toc+="<table><tr valign=top class='tocItemsH1 header1Content'>"
						+"<td class='header1Inside1'></td>"
						+"<td class='header1Inside2'>"
							+"<table><tr valign=top class='tocItemsH2 header2Content'>"
								+"<td class='header2Inside1'></td>"
								+"<td class='header2Inside2'>"
									+"<table><tr valign=top class='tocItemsH3 header3Content'>"
										+"<td class='header3Inside1'></td>"
										+"<td class='header3Inside2'>"
											+"<table><tr valign=top id='H-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"' class='tocItemsH4 header4Content'>"
												+"<td class='header4Inside1'>"
													+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
														+h4NumPersian
													+" </a>"
												+"</td>"
												+"<td class='header4Inside2'>"
													+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
														+header.innerHTML
													+"</a>"
												+"</td>"
											+"</tr></table>"
										+"</td>"
									+"</tr></table>"
								+"</td>"
							+"</tr></table>"
						+"</td>"
					+"</tr></table>";
					
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"' class='header4Content'>"
							+"<td class='header4Inside1'>"
								+"<a href='#H-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"' class='refToTOC' style=\"margin-right: 10px;\" onclick='currentPage="+tocOnWhichPage+"; changePage();'>"
									+h4NumPersian
								+"</a>"
							+"</td> "
							+"<td class='header4Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}
		}else if(header.getAttribute("kind")=="h5"){
			h5Num++; h6Num=-1;
			var h5NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num)+".&hairsp;"+abjad[h4Num]+".&hairsp;"+Roman[h5Num];
			
			if(document.getElementById("toc")==null){
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"' class='header5Content'>"
							+"<td class='header5Inside1'>"+h5NumPersian+"</td> "
							+"<td class='header5Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}else{
				var elementOnWhichPage=header.getAttribute("onPage");
				
				toc+="<table><tr valign=top class='tocItemsH1 header1Content'>"
						+"<td class='header1Inside1'></td>"
						+"<td class='header1Inside2'>"
							+"<table><tr valign=top class='tocItemsH2 header2Content'>"
								+"<td class='header2Inside1'></td>"
								+"<td class='header2Inside2'>"
									+"<table><tr valign=top class='tocItemsH3 header3Content'>"
										+"<td class='header3Inside1'></td>"
										+"<td class='header3Inside2'>"
											+"<table><tr valign=top class='tocItemsH4 header4Content'>"
												+"<td class='header4Inside1'></td>"
												+"<td class='header4Inside2'>"
													+"<table><tr valign=top id='H-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"' class='tocItemsH5 header5Content'>"
														+"<td class='header5Inside1'>"
															+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
																+h5NumPersian
															+" </a>"
														+"</td>"
														+"<td class='header5Inside2'>"
															+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
																+header.innerHTML
															+"</a>"
														+"</td>"
													+"</tr></table>"
												+"</td>"
											+"</tr></table>"
										+"</td>"
									+"</tr></table>"
								+"</td>"
							+"</tr></table>"
						+"</td>"
					+"</tr></table>";
					
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"' class='header5Content'>"
							+"<td class='header5Inside1'>"
								+"<a href='#H-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"' class='refToTOC' style=\"margin-right: 10px;\" onclick='currentPage="+tocOnWhichPage+"; changePage();'>"
									+h5NumPersian
								+"</a>"
							+"</td> "
							+"<td class='header5Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}
		}else if(header.getAttribute("kind")=="h6"){
			h6Num++;
			var h6NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num)+".&hairsp;"+abjad[h4Num]+".&hairsp;<span dir='ltr'>"+Roman[h5Num]+"</span>.&hairsp;"+roman[h6Num];
			
			if(document.getElementById("toc")==null){
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"."+h6Num+"' class='header6Content'>"
							+"<td class='header6Inside1'>"+h6NumPersian+"</td> "
							+"<td class='header6Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}else{
				var elementOnWhichPage=header.getAttribute("onPage");
				
				toc+="<table><tr valign=top class='tocItemsH1 header1Content'>"
						+"<td class='header1Inside1'></td>"
						+"<td class='header1Inside2'>"
							+"<table><tr valign=top class='tocItemsH2 header2Content'>"
								+"<td class='header2Inside1'></td>"
								+"<td class='header2Inside2'>"
									+"<table><tr valign=top class='tocItemsH3 header3Content'>"
										+"<td class='header3Inside1'></td>"
										+"<td class='header3Inside2'>"
											+"<table><tr valign=top class='tocItemsH4 header4Content'>"
												+"<td class='header4Inside1'></td>"
												+"<td class='header4Inside2'>"
													+"<table><tr valign=top class='tocItemsH5 header5Content'>"
														+"<td class='header5Inside1'></td>"
														+"<td class='header5Inside2'>"
															+"<table><tr valign=top id='H-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"."+h6Num+"' class='tocItemsH6 header6Content'>"
																+"<td class='header6Inside1'>"
																	+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"."+h6Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
																		+h6NumPersian
																	+" </a>"
																+"</td>"
																+"<td class='header6Inside2'>"
																	+"<a href='#header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"."+h6Num+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
																		+header.innerHTML
																	+"</a>"
																+"</td>"
															+"</tr></table>"
														+"</td>"
													+"</tr></table>"
												+"</td>"
											+"</tr></table>"
										+"</td>"
									+"</tr></table>"
								+"</td>"
							+"</tr></table>"
						+"</td>"
					+"</tr></table>";
					
				header.innerHTML="<table><tr valign=top id='header-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"."+h6Num+"' class='header6Content'>"
							+"<td class='header6Inside1'>"
								+"<a href='#H-"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"."+h6Num+"' class='refToTOC' style=\"margin-right: 10px;\" onclick='currentPage="+tocOnWhichPage+"; changePage();'>"
									+h6NumPersian
								+"</a>"
							+"</td> "
							+"<td class='header6Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			}
		}
	}
	// to substitute the generated TOC in its right place
	if(document.getElementById("toc") != null){
		toc=toc
			.replace(/(?:\<\/table\>\<table\>)/g,"")
			.replace(/(?:\<\/table\>\<\/td\>\<\/tr\>\<tr valign=top class\=\'tocItemsH1 header1Content\'\>\<td class\=\'header1Inside1\'\>\<\/td\>\<td class\=\'header1Inside2\'\>\<table\>)/g,"")
			.replace(/(?:\<\/table\>\<\/td\>\<\/tr\>\<tr valign=top class\=\'tocItemsH2 header2Content\'\>\<td class\=\'header2Inside1\'\>\<\/td\>\<td class\=\'header2Inside2\'\>\<table\>)/g,"")
			.replace(/(?:\<\/table\>\<\/td\>\<\/tr\>\<tr valign=top class\=\'tocItemsH3 header3Content\'\>\<td class\=\'header3Inside1\'\>\<\/td\>\<td class\=\'header3Inside2\'\>\<table\>)/g,"")
			.replace(/(?:\<\/table\>\<\/td\>\<\/tr\>\<tr valign=top class\=\'tocItemsH4 header4Content\'\>\<td class\=\'header4Inside1\'\>\<\/td\>\<td class\=\'header4Inside2\'\>\<table\>)/g,"")
			.replace(/(?:\<\/table\>\<\/td\>\<\/tr\>\<tr valign=top class\=\'tocItemsH5 header5Content\'\>\<td class\=\'header5Inside1\'\>\<\/td\>\<td class\=\'header5Inside2\'\>\<table\>)/g,"");
		
		toc=toc.replace(/(?:\<sup class\=\"tooltip)[^\r]*?(?:\<\/sup\>)/g,"");	// remove Footnotes from TOC
		document.getElementById("toc").innerHTML=toc+"<br>";
	}
	
	
	
	
	// to handle generating the list of relevent Footnotes at the end of each page
	if(ftnNum>=1){
		var ftnCurrentPage="";
		var i, ftnCounter=0;
		for(pageNum=0; pageNum<totalPageNumber; pageNum++){
			ftnCurrentPage="";
			for(i=ftnCounter; i<=ftnNum; i++){
				if(document.getElementById("ftn-"+i)!=null){
					if(document.getElementById("ftn-"+i).getAttribute("onPage")==pageNum){
						var ftnContent=document.getElementById("ftn-"+i+"-Hidden").firstChild.innerHTML;
						var directionMainText=document.getElementById("ftn-"+i+"-Hidden").getAttribute("directionMainText");
						//alert(directionMainText);
						
						ftnCurrentPage+=
							"<tr id='FTN-"+i+"'>"
								+"<td class='ftnNumbers'><sup><a href='#ftn-"+i+"' style='color:crimson;'>"+toFa(i)+"</a></sup></td>"
								+"<td class='ftnContents' style='text-align:"+directionMainText+";'>"+ftnContent+"</td>"
							+"</tr>";
							
						
						//to have "anchors" defined once, not twice; and only within the ftn at the bottom of the page
						// if it is to be used in the "Presentation" mode, then define anchors right beside the ftn call
						document.getElementById("ftn-"+i+"-Hidden").innerHTML = ("<span class='tooltipInnerContent'>"+ftnContent+"</span>").toString()
																		.replace(/(\<span id\=[\'\"]anchor\-.*[\'\"] onpage\=[\'\"]\d+[\'\"]\>\<\/span\>)/g,"")
																		//.replace(/(?:\/لنگرگاه)(?:\{[ \t]*(.*?)[ \t]*\})/g,"")
																		;
						
						ftnCounter=i;
					}
				}
			}
			if(ftnCurrentPage != ""){
				document.getElementById("ftnOnPage-"+pageNum).style.display="initial";
				document.getElementById("ftnColWrapperOnPage-"+pageNum).innerHTML="<table style='display:block'><tbody style='display:block'>"+ftnCurrentPage+"</tbody></table>";
			}
		}
	}
	
	
	
	
	// Now define the links for the cross-references
	result.innerHTML=result.innerHTML
		// for capturing references to already defined  پاورقی ...	   //use as   /پاورقی{کلید: key}
		.replace(/(?:\/پاورقی)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			var ftnNumToRefer=0, ftnPageNumToRefer, ftn, ftnContent, ftnWidth, ftnDir;
			for(var i=1; i<=ftnNum; i++){
				if(document.getElementById("ftn-"+i) && document.getElementById("ftn-"+i).getAttribute("key")==y){
					ftnNumToRefer=i;
					break;
				}
			}
			if(ftnNumToRefer==0){
				return "پاورقی <span style='color:crimson;'>؟؟</span>";
			}
			ftnPageNumToRefer=document.getElementById("ftn-"+ftnNumToRefer).getAttribute("onPage");
			ftn=document.getElementById("ftn-"+ftnNumToRefer+"-Hidden");
			ftnContent=ftn.innerHTML;
			
			//console.log(ftnContent);
			
			ftnWidth=ftn.getBoundingClientRect().width;
			ftnDir=ftn.style.textAlign;
			
			refFTN++;
			var idToCallFor="refFTN-"+refFTN;
			return "پاورقی "
					+"<span id='refFTN-"+refFTN+"' class='tooltip' onmouseover='tooltipRepositionCaller(\""+idToCallFor+"\");'>"
						+"<a href='#FTN-"+ftnNumToRefer+"' onclick='currentPage="+ftnPageNumToRefer+"; changePage();'>"
							+toFa(ftnNumToRefer)	//+" در صفحه‌ی "+toFa(Number(ftnPageNumToRefer)+1)
						+"</a>"
						+"<span id='refFTN-"+refFTN+"-Hidden' class='tooltipContent bottom' style='text-align:"+ftnDir+"; width:"+ftnWidth+"px;' >"
							+ftnContent
						+"</span>"
					+"</span>";
		})
		// for capturing references to already defined figures ...	   //use as   /شکل{کلید: key}
		.replace(/(?:\/شکل)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById("fig-"+y)){
				var elementOnWhichPage=document.getElementById("fig-"+y).getAttribute("onPage");
				var figNum=toEn(document.getElementById("fig-"+y).getAttribute("figNumber"));
				return 	"شکل <a href='#fig-"+y+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
							+toFa(figNum)
						+"</a>";
			}else{
				return	"شکل <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined فیلم ...	   //use as   /فیلم{کلید: key}
		.replace(/(?:\/فیلم)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById("video-"+y)){
				var elementOnWhichPage=document.getElementById("video-"+y).getAttribute("onPage");
				var vidNum=toEn(document.getElementById("video-"+y).getAttribute("videoNumber"));
				return 	"فیلم <a href='#video-"+y+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
							+toFa(vidNum)
						+"</a>";
			}else{
				return	"فیلم <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined صوت ...	   //use as   /صوت{کلید: key}
		.replace(/(?:\/صوت)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById("audio-"+y)){
				var elementOnWhichPage=document.getElementById("audio-"+y).getAttribute("onPage");
				var audNum=toEn(document.getElementById("audio-"+y).getAttribute("audioNumber"));
				return 	"صوت <a href='#audio-"+y+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
							+toFa(audNum)
						+"</a>";
			}else{
				return	"صوت <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined پنجره ...	   //use as   /پنجره{کلید: key}
		.replace(/(?:\/پنجره)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById("iFrame-"+y)){
				var elementOnWhichPage=document.getElementById("iFrame-"+y).getAttribute("onPage");
				var iFrameNum=toEn(document.getElementById("iFrame-"+y).getAttribute("iFrameNumber"));
				return 	"پنجره‌ی <a href='#iFrame-"+y+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
							+toFa(iFrameNum)
						+"</a>";
			}else{
				return	"پنجره‌ی <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined tables ...	   //use as   /جدول{key}
		.replace(/(?:\/جدول)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById("tbl-"+y)){
				var elementOnWhichPage=document.getElementById("tbl-"+y).getAttribute("onPage");
				var tblNum=toEn(document.getElementById("tbl-"+y).getAttribute("tblNumber"));
				return 	"جدول <a href='#tbl-"+y+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"
							+toFa(tblNum)
						+"</a>";
			}else{
				return	"جدول <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined sections ...	   //use as   /بخش{کلید: key}
		.replace(/(?:\/بخش)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			var headers=document.getElementsByClassName("header"),
				page, key, id, hNumber, htitle, keyFound=0;
			for (var i=0, l=headers.length; i<l; i++) {
				key=headers[i].getAttribute("key");
				if(key==y){
					id=headers[i].firstChild.firstChild.firstChild.id;
					page=headers[i].getAttribute("onPage");
					hNumber=document.getElementById(id).firstChild.innerHTML;
					htitle=document.getElementById(id).lastChild.innerHTML.replace(/(?:\<sup class\=\"tooltip)[^\r]*?(?:\<\/sup\>)/g,"");	// remove Footnotes from header's text;
					keyFound=1;
					break;
				}
			}
			if(keyFound==0){
				return "بخش <span style='color:crimson;'>؟؟</span>";
			}
			
			refHeader++;
			var idToCallFor="refHeader-"+refHeader;
			return "بخش "
					+"<span id='refHeader-"+refHeader+"' class='tooltip' onmouseover='tooltipRepositionCaller(\""+idToCallFor+"\");'>"
						+"<a href='#"+id+"' onclick='currentPage="+page+"; changePage();'>"
							+hNumber
						+"</a>"
						+"<span id='refHeader-"+refHeader+"-Hidden' class='tooltipContent bottom' style='text-align:center; white-space:nowrap;'>"
							+htitle
						+"</span>"
					+"</span>";
			
		})
		// to refer to the generated "لنگرگاه" ...	//use as   /لنگر{کلید: key}{متن لینک}
		.replace(/(?:\/لنگر)(?:\{کلید:[ \t]*(.*?)[ \t]*\})(?:\{[ \t]*(.*?)[ \t]*\})/g,  function(x,y1,y2){
			if(document.getElementById("anchor-"+y1)!=null){
				var elementOnWhichPage=document.getElementById("anchor-"+y1).getAttribute("onPage");
				return 	"<a href='#anchor-"+y1+"' onclick='currentPage="+elementOnWhichPage+"; changePage();'>"+y2+"</a>";
			}else{
				return	"<a href='#' onclick='alert(\"لنگرگاه این لنگر تعریف نشده است!\");'>"+y2+"</a>";
			}
		})
		
		
		// AGAIN for reference to footnotes, inside a reference to a footnote !!!  repeated from above
		.replace(/(?:\/پاورقی)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			var ftnNumToRefer=0, ftnPageNumToRefer, ftn, ftnContent, ftnWidth, ftnDir;
			for(var i=1; i<=ftnNum; i++){
				if(document.getElementById("ftn-"+i) && document.getElementById("ftn-"+i).getAttribute("key")==y){
					ftnNumToRefer=i;
					break;
				}
			}
			if(ftnNumToRefer==0){
				return "پاورقی <span style='color:crimson;'>؟؟</span>";
			}
			ftnPageNumToRefer=document.getElementById("ftn-"+ftnNumToRefer).getAttribute("onPage");
			ftn=document.getElementById("ftn-"+ftnNumToRefer+"-Hidden");
			ftnContent=ftn.innerHTML;
			
			//console.log(ftnContent);
			
			ftnWidth=ftn.getBoundingClientRect().width;
			ftnDir=ftn.style.textAlign;
			
			refFTN++;
			var idToCallFor="refFTN-"+refFTN;
			return "پاورقی "
					+"<span id='refFTN-"+refFTN+"' class='tooltip' onmouseover='tooltipRepositionCaller(\""+idToCallFor+"\");'>"
						+"<a href='#FTN-"+ftnNumToRefer+"' onclick='currentPage="+ftnPageNumToRefer+"; changePage();'>"
							+toFa(ftnNumToRefer)	//+" در صفحه‌ی "+toFa(Number(ftnPageNumToRefer)+1)
						+"</a>"
						+"<span id='refFTN-"+refFTN+"-Hidden' class='tooltipContent bottom' style='text-align:"+ftnDir+"; width:"+ftnWidth+"px;' >"
							+ftnContent
						+"</span>"
					+"</span>";
		});
	
	
	
	// to handle the references, generating the list of references and managing how to cite them
	if(document.getElementById("listOfReferences")!=null){
		
		if(document.getElementById("toc")==null){
			document.getElementById("listOfReferences").innerHTML="<div class='header' id='references-section'>مراجع</div>";
		}else{
			var RefsOnWhichPage=document.getElementById("listOfReferences").getAttribute("onPage");
			toc+="<div id='References'><a href='#references-section' onclick='currentPage="+RefsOnWhichPage+"; changePage();'>مراجع</a></div><br>";
			document.getElementById("toc").innerHTML=toc;
				
			document.getElementById("listOfReferences").innerHTML="<div class='header' id='references-section'>مراجع "
				+"<a href='#References' onclick='currentPage="+tocOnWhichPage+"; changePage();' style='font-size:small; color:cyan; border:1px groove cyan'>↩</a>"
			+"</div>";
		}
		
		document.getElementById("listOfReferences").innerHTML+="<ol id='ref'></ol>";
		
		var draftListOfReferences=[];
		// then first write each reference in its proper style, then push it  as an item into the list of references:
		var references = document.getElementsByTagName("my-references");
		for (var i = 0, l=references.length; i<l ; i++) {
			var reference=references[i];
			
			reference.innerHTML="<span author=\""+reference.getAttribute("author")+"\" year=\""+reference.getAttribute("year")+"\" id=\""+reference.getAttribute("key")+"\">";	// author and year attributes are held as sorting the references would be with respect to them
			if(reference.getAttribute("author")){
				reference.innerHTML+=reference.getAttribute("author");
			}
			if(reference.getAttribute("year")){
				reference.innerHTML+=" ("+reference.getAttribute("year")+")";
			}
			if(reference.getAttribute("language")=="en"){
				if(reference.getAttribute("title")){
					reference.innerHTML+=" \“<strong>"+reference.getAttribute("title")+"</strong>\”";
				}
				if(reference.getAttribute("publisher")){
					reference.innerHTML+=", <em>"+reference.getAttribute("publisher")+"</em>";
				}
				if((reference.getAttribute("author") || reference.getAttribute("title")) && reference.getAttribute("comment")){
					reference.innerHTML+=", "+reference.getAttribute("comment");
				}else if(!reference.getAttribute("author") && !reference.getAttribute("title") && reference.getAttribute("comment")){
					reference.innerHTML+=reference.getAttribute("comment");
				}
			}else{
				if(reference.getAttribute("title")){
					reference.innerHTML+=" «<strong>"+reference.getAttribute("title")+"</strong>»";
				}
				if(reference.getAttribute("publisher")){
					reference.innerHTML+="، <em>"+reference.getAttribute("publisher")+"</em>";
				}
				if((reference.getAttribute("author") || reference.getAttribute("title")) && reference.getAttribute("comment")){
					reference.innerHTML+="، "+reference.getAttribute("comment");
				}else if(!reference.getAttribute("author") && !reference.getAttribute("title") && reference.getAttribute("comment")){
					reference.innerHTML+=reference.getAttribute("comment");
				}
			}
			reference.innerHTML+="</span>";
			
			draftListOfReferences.push(reference.innerHTML);	// populate the array draftListOfReferences
			
		}
		
		// to sort the list of references in authors and year of published works
		if(document.getElementById("listOfReferences").getAttribute("ordered")){
			draftListOfReferences.sort();		// Sort it , sorting first acts on <span author="..." year="..." id="key"> and then the rest of the reference details in the <span>, so it actually sorts first the authors, then the years, then ...
			//draftListOfReferences.reverse();	// to sort the array in descending form
		}
		
		var draftReference=document.createElement("span");
		for(var i=0, l=draftListOfReferences.length; i < l; i++){	// now populate the main ordered list of Refs
			draftReference.innerHTML=draftListOfReferences[i];
			var id=draftReference.querySelector("span").getAttribute("id");
			var reference=document.querySelector("[key='" + id + "']");
			if(reference.getAttribute("language")=="en"){
				document.getElementById("ref").innerHTML += "<li style='margin-left:20px; margin-right:-10px; padding-left:5px; padding-right:5px; text-align:justify;' dir='ltr'><span style='font-family:en1, fa1;'>"+draftListOfReferences[i]+"</span></li>";
				//document.getElementById("ref").innerHTML += "<li style='direction:ltr; text-align:left; float:left;'><span style='font-family:en1;'>"+draftListOfReferences[i]+"</span></li>";
			}else{
				document.getElementById("ref").innerHTML += "<li style='margin-right:-10px; margin-left:20px; padding-right:5px; padding-left:5px;'>"+draftListOfReferences[i]+"</li>";
			}
		}
		
		
		// now let handle the citations to the references listed in the list of references ... inspired by: http://folk.uib.no/plo092/katex/#saevik
		var txlist = document.getElementsByTagName("my-citation");
		for (var i = 0, l=txlist.length; i<l ; i++) {
			var citeref = txlist[i];
			var RefsOnWhichPage=document.getElementById("listOfReferences").getAttribute("onPage");
			if(citeref.getAttribute("description")){
				citeref.innerHTML = "[<a href='#" + citeref.textContent + "' onclick='currentPage="+RefsOnWhichPage+"; changePage();'></a><span>،</span> "+citeref.getAttribute("description")+"]";
			}else{
				citeref.innerHTML = "[<a href='#" + citeref.textContent + "' onclick='currentPage="+RefsOnWhichPage+"; changePage();'></a>]";
			}
		}
		var lis = document.getElementById("ref").getElementsByTagName("li");
		var uncitedRefs=[];
		for (var i=0, l=lis.length; i<l ; i++) {
			var span=lis[i].querySelector("span");
			var id = (span.getAttribute("id"))?  span.getAttribute("id") : span.querySelector("span").getAttribute("id") ;
			//var id=lis[i].querySelector("span").getAttribute("id");	// when lang=en there is added also another span, so I shoul check it and control which span is selected here
			var reference=document.querySelector("[key='" + id + "']");
			//alert(reference);
			var tx2list = document.querySelectorAll("my-citation a[href='#" + id + "']");
			//alert(tx2list.length);
			//alert(i);
			var refNumber=toFa((i+1).toString());
			if(tx2list.length==0){
				uncitedRefs.push(refNumber+" ["+reference.getAttribute("shortRef")+"]");
			}
			for (var j = 0, len=tx2list.length; j<len ; j++) {
				tx2list[j].innerHTML =refNumber;
				tx2list[j].setAttribute("title", reference.getAttribute("shortRef"));
				if(reference.getAttribute("language")=="en"){
					//tx2list[j].parentNode.querySelector("span").innerHTML=",";
					tx2list[j].setAttribute("dir", "ltr");   //this is required for the title of the link to be "ltr"!
				}
			}
		}
		if(uncitedRefs.length!=0) {alert("به مرجع "+uncitedRefs.join(" و ")+" در متن نوشتار اشاره‌ای انجام نگرفته است!");}
	}
	
	
	
	// to make the footnotes at the bottom of the specified page typesetted in one single column
	for(pageNum=0; pageNum<totalPageNumber; pageNum++){
		var currentPageContent=document.getElementById("resultPage-"+pageNum).innerHTML;
		currentPageContent=currentPageContent.replace(/(?:\/پا۱\/)/g, function(x){
			document.getElementById("ftnColWrapperOnPage-"+pageNum).classList.add("singleFtnCol");
			//alert(document.getElementById("ftnColWrapperOnPage-"+pageNum).classList);
			return "";
		});
		//alert(document.getElementById("ftnColWrapperOnPage-"+pageNum).classList);
	}
	// the line below should not have been required, but IT IS, but why? // this is now just like a dirty hack
	result.innerHTML=result.innerHTML.replace(/(?:\/پا۱\/)/g,"");		
	
	
	
	htmlExport=result.innerHTML;	// the "result"'s content before applying MathJax, required for publishing the output as a new HTML
	
	
	
	MathJax.texReset();
	MathJax.typesetClear();
	MathJax.typeset();
	
	// to handle cross-referencing the equations in MathJax, due to the multipage nature of the document
	var perPageEqs=[];
	for(pageNum=0; pageNum<totalPageNumber; pageNum++){
		var jax = MathJax.getAllJax("resultPage-"+pageNum);
		var neWLabelsInPage=[];
		for (var i=0, l=jax.length; i<l; i++) {
			//alert(jax[i].math);
			jax[i].math.replace(/\\label\{([^\}]+)\}/g, function(x,y){
				neWLabelsInPage.push(y);
				return false;
			});
		}
		perPageEqs.push(neWLabelsInPage);
	}
	//alert(JSON.stringify(perPageEqs));
	result.innerHTML=result.innerHTML
		.replace(/(href\=\"\#mjx\-eqn\-([^\"]*)\")/g,  function(x,y1,y2){
			eqonwpVar=perPageEqs.findIndex(function(x) {
				return x.indexOf(y2) !== -1;
			});
			//alert(y1+" onclick=\"currentPage="+eqonwpVar+"; changePage();\"");
			return y1+" onclick=\"currentPage="+eqonwpVar+"; changePage();\"";
		});
	
	
	
	
	//numbering the presentation items by giving them suitable IDs
	// class='item active' onPage='"+pageNumVar+"' inRange='"+range+"'
	/*
	allItems=[];
	for(pageNum=0; pageNum<totalPageNumber; pageNum++){
		var div=document.getElementById("resultPage-"+pageNum);
		var allItemsInPage=div.getElementsByClassName("item");
		var counterSteps=0, totalSteps=0;
		for(var i=0, leni=allItemsInPage.length; i<leni; i++){
			var range=allItemsInPage[i].getAttribute("inRange");
			var numbers=[];
			range=range.split(/[ \t]+/);
			for(var j=0, lenj=range.length; j<lenj; j++){
				if(range[j].indexOf('-') > -1){
					var x=range[j].replace(/([\d۰۱۲۳۴۵۶۷۸۹]*)\-+([\d۰۱۲۳۴۵۶۷۸۹]*)/g, function(x,y1,y2){
						y1=toEn(y1);
						y2=toEn(y2);
						var c;	if(y1>y2){c=y1; y1=y2; y2=c;}
						var y=[];
						for(var k=y1; k<=y2; k++){
							y.push(k);
						}
						return y;
					});
				}else{
				}
			}
		}
	}
	*/
	allItems=document.getElementsByClassName("item");
	for(var i=0, l=allItems.length; i<l; i++){
		allItems[i].id="item-"+i;
		if(allItems[i].classList.contains('hover')){  //this class is useful only in Presentation Mode, the hover effects
			allItems[i].classList.remove('hover');
		}
	}
	// to check each page contains which items, required for correct navigation in the  PRESENTATION mode
	perPageItems=[];
	for(pageNum=0; pageNum<totalPageNumber; pageNum++){
		var div=document.getElementById("resultPage-"+pageNum);
		perPageItems.push(	(div.querySelectorAll('[id^=item-]') || []).length	);	// count items per page
	}
	cumulativeInPageItems=[ perPageItems[0] ];
	for(pageNum=1; pageNum<totalPageNumber; pageNum++){
		cumulativeInPageItems.push( perPageItems[pageNum]+cumulativeInPageItems[pageNum-1] );
	}
	
	
	
	
	changePage();
}
function parseFootnotes(string) {
	//alert(string);
	return string
		// for capturing footnotes, the source being like (٬٬ text ٬٬)
		.replace(/(?:\(٬٬)((و|چ|وچ|چچ)?([۰۱۲۳۴۵۶۷۸۹\d]*)(?:\[[ \t\n]*(.*?)[ \t\n]*\])?\/)?[ \t\n]*([\s\S]*?)[ \t\n]*(?:٬٬\))/g, function(x,y1,y2,y3,y4,y5){
			var directionPopup="right", directionMainText="justify";
			if(y2){
				switch(y2) {
					case "و":
						directionPopup="center";
						break;
					case "چ":
						directionPopup="left";
						break;
					case "وچ":
						directionPopup="center";
						directionMainText="left";
						break;
					case "چچ":
						directionPopup="left";
						directionMainText="left";
						break;
				}
			}
			var tooltipwidth = (y3)? toEn(y3.replace(/ */g,""))+"px" : "250px";
			var key=(y4)? y4 : "";
			
			ftnNum++;
			//y=parseStyles(y);
			//y=parseTables(y);
			//y=parseFigures(y);
			//y=parseVideos(y);
			//y=parseAudios(y);
			//y=parseiFrames(y);
			//y=parseStyles(y);
			y5=parseListItems(y5);
			//y=parsePresentationItems(y);
			y5=parseEnvironments(y5);
			//y=parseReferences(y);
			//y=parseSymbols(y);
			
			y5=(y1 && !y2 && !y3 && !y4)? "/"+y5 : y5;
			
			
			var idToCallFor="ftn-"+ftnNum;
			return "<sup class='tooltip' onmouseover='tooltipRepositionCaller(\""+idToCallFor+"\");'>"
				+"<a href='#FTN-"+ftnNum+"' id='ftn-"+ftnNum+"' style='font-size:90%; color:crimson;' onPage='"+pageNumVar+"' key='"+key+"'>"
					+toFa(ftnNum)
				+"</a>"
				+"<span id='ftn-"+ftnNum+"-Hidden' class='tooltipContent bottom' style='text-align:"+directionPopup+"; width:"+tooltipwidth+"' directionMainText='"+directionMainText+"' onmouseout='"
												+"if(this.matches(':hover')){this.style.visibility='visible'; thiis.style.opacity='1';}"
												+"else{setTimeout(function(){this.style.visibility='hidden'; thiis.style.opacity='0';}, 2000);}"
											+"'>"
					+"<span class='tooltipInnerContent'>"+y5+"</span>"
				+"</span>"
			+"</sup>";
		});
}
function tooltipRepositionCaller(id){
	//console.log(id);
	var el=document.getElementById(id),
		elTooltip=document.getElementById(id+"-Hidden");
	tooltipReposition(el , elTooltip);
}
function tooltipReposition(el,eltt){
	var relativeLeft= el.getBoundingClientRect().left - resultWrapper.getBoundingClientRect().left,
		relativeTop= el.getBoundingClientRect().top - resultWrapper.getBoundingClientRect().top;
	
	var resultWrapperWidth=resultWrapper.clientWidth,
		resultWrapperHeight=resultWrapper.clientHeight;
	
	
	if(relativeTop <= Math.floor(resultWrapperHeight/2) && relativeLeft < Math.floor(resultWrapperWidth/3)){
		eltt.className = "tooltipContent bottomRight";
	}else if(relativeTop <= Math.floor(resultWrapperHeight/2) && relativeLeft > Math.floor(2*resultWrapperWidth/3)){
		eltt.className = "tooltipContent bottomLeft";
	}else if(relativeTop <= Math.floor(resultWrapperHeight/2)){
		eltt.className = "tooltipContent bottom";
	}else if(relativeTop > Math.floor(resultWrapperHeight/2) && relativeLeft < Math.floor(resultWrapperWidth/3)){
		eltt.className = "tooltipContent topRight";
	}else if(relativeTop > Math.floor(resultWrapperHeight/2) && relativeLeft > Math.floor(2*resultWrapperWidth/3)){
		eltt.className = "tooltipContent topLeft";
	}else{
		eltt.className = "tooltipContent top";
	}
}
function parseTables(string) {
	string=string
			// for capturing "tables" ...
			// [class], [caption] & [key] in   /جدول.ش[key][class][caption]  are all optional ...
			.replace(/(?:\/جدول.ش\/)(?:\[کلید:[ \t]*(.*?)[ \t]*\])?(?:\[کلاس:[ \t]*(.*?)[ \t]*\])?(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?/g, function(x,y1,y2,y3){
				tblNum++;
				var tblNumPersian=toFa(tblNum.toString());
				if(y3!=undefined){
					//y3=parseStyles(y3);
					//y3=parseTables(y3);
					y3=parseFigures(y3);
					//y3=parseVideos(y3);
					//y3=parseAudios(y3);
					//y3=parseiFrames(y3);
					//y3=parseFootnotes(y3);
					y3=parseListItems(y3);
					y3=parsePresentationItems(y3);
					y3=parseEnvironments(y3);
					//y3=parseReferences(y3);
					//y3=parseSymbols(y3);
				}
				var captionTail=(y3==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y3+"</span>";
				return "<table id='tbl-"+y1+"' tblNumber='"+tblNumPersian+"' class='"+y2+"' onPage='"+pageNumVar+"' style='margin-top:-20px;'>"
						+"<caption>"
							+"<span style='color:crimson;'>جدول "+tblNumPersian+""+captionTail
						+"</caption>";
			})
			// not numbered. not referrable, not increasing the table counter, not having any caption
			.replace(/(?:\/جدول.ش\*\/)(?:\[کلاس:[ \t]*(.*?)[ \t]*\])?/g, "<table class='$1'>")
			
			// to capture each row in the tables
			.replace(/(?:\/ردیف\/)[\t\n\r ]*(.*?)[\t\n\r ]*(?=\/ردیف\/|\/جدول\.پ\/|\r|\n|\t)/g,"<tr>$1</tr>")
			
			// to capture each column in each row, with possible different optional styles for it
			.replace(/(?:\|\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td>"+y+"</td>";
			})
			.replace(/(?:\|ر\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style='text-align:right'>"+y+"</td>";
			})
			.replace(/(?:\|ر.ب\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:top; text-align:right;\">"+y+"</td>";
			})
			.replace(/(?:\|ر.پ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:bottom; text-align:right;\">"+y+"</td>";
			})
			.replace(/(?:\|چ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style='text-align:left'>"+y+"</td>";
			})
			.replace(/(?:\|چ.ب\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:top; text-align:left;\">"+y+"</td>";
			})
			.replace(/(?:\|چ.پ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:bottom; text-align:left;\">"+y+"</td>";
			})
			.replace(/(?:\|ب\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style='vertical-align:top;'>"+y+"</td>";
			})
			.replace(/(?:\|پ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(y);
					y=parseFigures(y);
					y=parseVideos(y);
					y=parseAudios(y);
					y=parseiFrames(y);
					y=parseFootnotes(y);
					y=parseListItems(y);
					y=parsePresentationItems(y);
					y=parseEnvironments(y);
					//y=parseReferences(y);
					//y=parseSymbols(y);
				}*/
				return "<td style='vertical-align:bottom;'>"+y+"</td>";
			})
			
			.replace(/[ \t\n]*(?:\/جدول.پ\/)/g,"</table>")	// to end the tables;
	return string;
}
function parseStyles(string) {
	string=string
			// for capturing new styles defined by the user, to be considered as lying in the header of the HTML file
			.replace(/(\/استایل\/)[ \t\n]*(?=\S)([^\r]*?\S[*_]*)[ \t\n]*\1/g,  function(x,y1,y2){
				var style = document.createElement('style');
				style.type = 'text/css';
				style.innerHTML = y2;
				document.getElementsByTagName('head')[0].appendChild(style);
				
				// keep these styles in html file which is generated by the program
				userDefinedCSS+="<style type='text/css'>"+y2+"</style>";
				
				//document.body.appendChild(style);
				/*
				if (style.styleSheet) style.styleSheet.cssText = y2;				// Supports IE
				else style.appendChild(document.createTextNode(y2));			// Supports the rest
				document.getElementsByTagName("head")[0].appendChild(style);	// where to place the style
				*/
				return "";		// if it was not added, an "undefined" text was written in its place!
			})
			;
	return string;
}
function parseFigures(string) {
	string=string
			//for capturing INLINE figures ...
			//use as  /شکل*{folder/image.gif}[300:200][چب۱٫۵]
			.replace(/(?:\/شکل\*[ \t]*)(?:\{[ \t]*([^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*([*\d]+[A-Za-z%]{0,4})?[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})?[ \t]*\])?(?:\[([روچ])?([بوپ])?([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				var figWidth=(y2!=undefined)? y2 : "*" ;
				var figHeight=(y3!=undefined)? y3 : "*" ;
				var s="";
				if(y6!=undefined){
					var scale = toEn(y6.replace(/[\/٫٬]/,"."));
					var originX="center", originY="center";
					if(y4!=undefined){
						switch(y4){
							case "ر":
								originX ="right";
								break;
							/*case "و":
								//originX = "center";
								break;*/
							case "چ":
								originX ="left";
								break;
							/*default:
								originX = "center";*/
						}
					}
					if(y5!=undefined){
						switch(y5){
							case "ب":
								originY ="top";
								break;
							/*case "و":
								originY = "center";
								break;*/
							case "پ":
								originY ="bottom";
								break;
							/*default:
								originY = "center";*/
						}
					}
					s = "onmouseover= ' "
							+"this.style.transformOrigin = \""+originX+" "+originY+"\"; "
							+"this.style.transform = \"scale("+scale+")\";"
						+" '"
						+" onmouseout= ' this.style.transform = \"none\"; '";
				}
				return "<img src='"+y1+"' width='"+figWidth+"' height='"+figHeight+"' style='margin-bottom:"+(-figHeight/2+5)+"px;' "+s+">";
			})

			//for capturing NUMBERED figures ...
			//use as  /شکل{folder/image.gif}[300:200][: توضیحات شکل که زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان شکل]
			.replace(/(?:\/شکل[ \t]*)(?:\{[ \t]*([^ک][^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t\n]*(?:\[([روچ])?([بوپ])?([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)[ \t]*\])?/g, function(x,y1,y2,y3,y4,y5,y6,y7,y8,y9){
				figNum++;
				var figNumPersian=toFa(figNum.toString());var figWidth=(y2!=undefined)? y2 : "*" ;
				var figHeight=(y3!=undefined)? y3 : "*" ;
				var s="";
				if(y6!=undefined){
					var scale = toEn(y6.replace(/[\/٫٬]/,"."));
					var originX="center", originY="center";
					if(y4!=undefined){
						switch(y4){
							case "ر":
								originX ="right";
								break;
							/*case "و":
								//originX = "center";
								break;*/
							case "چ":
								originX ="left";
								break;
							/*default:
								originX = "center";*/
						}
					}
					if(y5!=undefined){
						switch(y5){
							case "ب":
								originY ="top";
								break;
							/*case "و":
								originY = "center";
								break;*/
							case "پ":
								originY ="bottom";
								break;
							/*default:
								originY = "center";*/
						}
					}
					s = "onmouseover= ' "
							+"this.style.transformOrigin = \""+originX+" "+originY+"\"; "
							+"this.style.transform = \"scale("+scale+")\";"
						+" '"
						+" onmouseout= ' this.style.transform = \"none\"; '";
				}
				if(y7!=undefined){
					//y7=parseStyles(y7);
					//y7=parseTables(y7);
					//y7=parseFigures(y7);
					//y7=parseVideos(y7);
					//y7=parseAudios(y7);
					//y7=parseiFrames(y7);
					//y7=parseFootnotes(y7);
					y7=parseListItems(y7);
					y7=parsePresentationItems(y7);
					y7=parseEnvironments(y7);
					//y7=parseReferences(y7);
					//y7=parseSymbols(y7);
				}
				var captionTail=(y7==undefined)?  "</span>"  :  ":</span> <span class='captionContent'>"+y7+"</span>" ;
				var figID=(y8!=undefined)? " id='fig-"+y8+"' " : " " ;
				var figTitle=(y9!=undefined)? " title='"+y9+"' " : " " ;
				return "<figure style='text-align:center; align-content:center; margin:auto; margin-bottom:-20px;'>"
						+"<img"+figID+"figNumber='"+figNumPersian+"' src='"+y1+"' width='"+figWidth+"' height='"+figHeight+"' "+s+figTitle+" onPage='"+pageNumVar+"'>"
						+"<figcaption>"
							+"<span style='color:crimson;'>شکل "+figNumPersian+captionTail
						+"</figcaption>"
					+"</figure>";
			});
	return string;
}
function parseVideos(string) {
	string=string
			//for capturing videos ...
			//use as	/فیلم{"folder/video.mp4" "folder/video.webm"}[زیرنویس: "folder/subtitle1.vtt?en" "folder/subtitle2.vtt?fa"][320:240][: توضیحات فیلم که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان فیلم]
			.replace(/(?:\/فیلم[ \t]*)(?:\{[ \t]*([^ک][^\}]*)\})[ \t]*(?:\[[ \t]*زیرنویس\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5,y6,y7){
				videoNum++;
				var videoNumPersian=toFa(videoNum.toString());
				var sources=y1.replace(/(\"[^\"]*\")/g,"<source src=$1>");
				var subtitles=(y2==undefined)? "" : y2.replace(/(?:\"([^\?]*)\?([^\"]*)\")/g,"<track src\=\"$1\" kind=\"subtitles\" srclang\=\"$2\" label\=\"$2\" default>");
				if(y5!=undefined){
					//y5=parseStyles(y5);
					//y5=parseTables(y5);
					//y5=parseFigures(y5);
					//y5=parseVideos(y5);
					//y5=parseAudios(y5);
					//y5=parseiFrames(y5);
					//y5=parseFootnotes(y5);
					y5=parseListItems(y5);
					y5=parsePresentationItems(y5);
					y5=parseEnvironments(y5);
					//y5=parseReferences(y5);
					//y5=parseSymbols(y5);
				}
				var captionTail=(y5==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y5+"</span>";
				var divWidth=(y3==undefined)? "" : (y3.indexOf("\%")!=-1 || y3.indexOf("٪")!=-1 || y3.indexOf("px")!=-1)? "style='width:"+y3.replace(/٪/,"%")+"!important;" :	 "style='width:"+y3+"px!important;";
				var videoWidth=(y3!=undefined)? " width='"+y3+"' " : "" ;
				var videoHeight=(y4!=undefined)? " height='"+y4+"' " : "" ;
				return "<div class=\"videoContainer\" "+divWidth+" '>"
						+"<video id='video-"+y6+"' videoNumber='"+videoNumPersian+"' "+ videoWidth + videoHeight +" title='"+y7+"' onPage='"+pageNumVar+"' controls>"
							+sources
							+subtitles
						+"مرورگر شما از HTML5 video پشتیبانی نمی‌کند."
						+"</video>"
						+"<br><span style=\"font-size:90%!important;\"><span style='color:crimson;'>فیلم "+videoNumPersian+""+captionTail+"</span>"
					+"</div>";
			});
	return string;
}
function parseAudios(string) {
	string=string
			//for capturing audios ...
			//use as	/صوت{"folder/audio.ogg" "folder/audio.mp3"}[400][: توضیحات صوتی که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان صوت]
			.replace(/(?:\/صوت[ \t]*)(?:\{[ \t]*([^ک][^\}]*)\})[ \t]*(?:\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5){
				audioNum++;
				var audioNumPersian=toFa(audioNum.toString());
				var sources=y1.replace(/(\"[^\"]*\")/g,"<source src=$1>");
				if(y3!=undefined){
					//y3=parseStyles(y3);
					//y3=parseTables(y3);
					//y3=parseFigures(y3);
					//y3=parseVideos(y3);
					//y3=parseAudios(y3);
					//y3=parseiFrames(y3);
					//y3=parseFootnotes(y3);
					y3=parseListItems(y3);
					y3=parsePresentationItems(y3);
					y3=parseEnvironments(y3);
					//y3=parseReferences(y3);
					//y3=parseSymbols(y3);
				}
				var captionTail=(y3==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y3+"</span>" ;
				var divWidth=(y2==undefined)? "" : (y2.indexOf("\%")!=-1 || y2.indexOf("٪")!=-1 || y2.indexOf("px")!=-1)? y2.replace(/٪/,"%") : y2+"px";
				return "<div class=\"audioContainer\" style='width:"+divWidth+"!important;'>"
						+"<audio id='audio-"+y4+"' audioNumber='"+audioNumPersian+"' style='width:"+divWidth+"!important;' title='"+y5+"' onPage='"+pageNumVar+"' controls>"
							+sources
						+"مرورگر شما از HTML5 audio پشتیبانی نمی‌کند."
						+"</audio>"
						+"<br><span style=\"font-size:90%!important;\"><span style='color:crimson;'>صوت "+audioNumPersian+""+captionTail+"</span>"
					+"</div>";
			});
	return string;
}
function parseiFrames(string) {
	string=string
			//for capturing (interactive) iFrames ...
			//use as  /پنجره{folder/iFrame.html}[320:240][: توضیحات پنجره که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن]
			.replace(/(?:\/پنجره[ \t]*)(?:\{[ \t]*([^ک][^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*(\d+)?[ \t]*\:[ \t]*(\d+)?[ \t]*(?:\-[ \t]*([\.\d]+)?[ \t]*)?[ \t]*\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				iFrameNum++;
				var iFrameNumPersian=toFa(iFrameNum.toString());
				
				var iFrameWidth=(y2!=undefined)? y2 : "500" ;
				var iFrameHeight=(y3!=undefined)? y3 : "500" ;
				var zoom=(y4!=undefined)?  (y4*1.0)  :  1.0  ;
				//var iFramePadding=" calc( ( "+zoom+" - 1.0 ) * 0.5 * "+ iFrameWidth +")";
				
				var iFrameStyle=" style=\""
										+"width:"+ (iFrameWidth / zoom) +"px; "
										+"height:"+ (iFrameHeight / zoom) +"px; "
										+"transform: scale("+zoom+"); "
										+"transform-origin: right bottom; "
										+"margin-left: "+ ((zoom - 1.0) * iFrameWidth / zoom) +"px; "
										+"margin-top: "+ ((zoom - 1.0) * iFrameHeight / zoom) +"px;"
									+"\" ";
				
				var scrollTo=" onload=\""
									+"this.contentWindow.document.documentElement.scrollLeft="
											+"this.contentWindow.document.documentElement.scrollWidth / 3; "
									+"this.contentWindow.document.documentElement.scrollTop="
											+"this.contentWindow.document.documentElement.scrollHeight / 3; "
								+"\" ";
				
				if(y5!=undefined){
					//y5=parseStyles(y5);
					//y5=parseTables(y5);
					//y5=parseFigures(y5);
					//y5=parseVideos(y5);
					//y5=parseAudios(y5);
					//y5=parseiFrames(y5);
					//y5=parseFootnotes(y5);
					y5=parseListItems(y5);
					y5=parsePresentationItems(y5);
					y5=parseEnvironments(y5);
					//y5=parseReferences(y5);
					//y5=parseSymbols(y5);
				}
				var captionTail=(y5==undefined)?  "</span>"  :  ":</span> <span class='captionContent'>"+y5+"</span>" ;
				var iFrameID=(y6!=undefined)? " id='iFrame-"+y6+"' " : "" ;
				return "<div class=\"iFrameContainer\">"
						+"<iframe src='"+y1+"' class=\"iFrame\" "
							+ iFrameStyle + scrollTo + iFrameID
							+"iFrameNumber='"+iFrameNumPersian+"' onPage='"+pageNumVar+"'>"
						+"</iframe>"
						+"<br>"
						+"<span style=\"font-size:90%!important;\"><span style='color:crimson;'>پنجره‌ی "
							+ iFrameNumPersian + captionTail
						+"</span>"
					+"</div>";
			});
	return string;
}
function parseListItems(string) {
	string=string
			//	.*	.+	.**	.++[✍]	.*+*	....
			.replace(/^[ \t]*(\.)?(\+|\*)(-?[\d۰-۹]+)?(.*)$/gm, function(x,y1,y2,y3,y4){
				var i=1;	if(i > nestedListLevel){nestedListLevel=i;}
				var mar=(y3!=undefined)?     " style='margin-right:"+toEn(y3)+"px;'"   : "" ;
				y4=(y2=="+")? "<ol"+mar+"><li>"+y4+"</li></ol>" : "<ul"+mar+"><li>"+y4+"</li></ul>";
				var temp=1, yt=y4, ytt="";
				while(temp){
					ytt=yt	.replace(/\<li\>(?:\+)[ \t]*(.+)\<\/li\>/, "<ol><li>$1</li></ol>")
							.replace(/\<li\>(?:\*)[ \t]*(.+)\<\/li\>/, "<ul><li>$1</li></ul>");
					if(ytt==yt){
						temp=0;		// so the loop is terminated
						i--;
						
						// to let change the bullet fot this item and its following of the same level
						ytt=ytt.replace(/(?:\<ul\>\<li\>)(?:\[(.*)\])?/, function(x,y){
							return (y!=undefined)? "<ul style='list-style:\" "+y+" \" outside;'><li>" : "<ul><li>";
						});
					}
					yt=ytt;
					i++; if(i > nestedListLevel){nestedListLevel=i;}
				}
				if(y1!=undefined){
					yt=yt.replace(/\<li\>([^\<]+)\<\/li\>/g,"<li class='item active'>$1</li>");
				}
				//console.log(yt);
				return yt;
			});
	return string;
}
function parsePresentationItems(string) {
	string=string
			// to place each item inside a div, used in Presentation Mode for step-wise appearance of the items
			//	/:/.../:/	/./..././	/../.../../	.*	.**	.+	.++	etc.
			.replace(/(\/\:\/)(?:\{([\d۰۱۲۳۴۵۶۷۸۹\- \t]+)\})?[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g, function(x,y1,y2,y3){
				var range=(y2!=undefined)? y2 : "All";
				return "<div class='item active' onPage='"+pageNumVar+"' inRange='"+range+"'>"+y3+"</div>";
			})
			.replace(/(\/\.\/)(?:\{([\d۰۱۲۳۴۵۶۷۸۹\- \t]+)\})?[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,  function(x,y1,y2,y3){
				var range=(y2!=undefined)? y2 : "All";
				return "<span class='item active' onPage='"+pageNumVar+"' inRange='"+range+"'>"+y3+"</span>";
			})
			
			// to do the same in mathematics using \class{active}{math}
			// ( functionality like in https://mathjax.github.io/MathJax-demos-web/reveal-steps.html )
			// {\s ... \s}
			.replace(/(?:\{\\s([\s\S]*?)\\s\})/g,"\\class{item active}{$1}")
			
			
			;
	return string;
}
function parseEnvironments(string) {
	string=string
			.replace(/(\/ن\/)[ \t\n]*([\S\s]*?)[ \t\n]*\1/g,"<blockquote>$2</blockquote>")
			
			.replace(/(?:\/چند.س([۰۱۲۳۴۵۶۷۸۹\d]+)?\/)[ \t\n]*([\S\s]*?)[ \t\n]*(?:\/چند.س\/)/g, function(x,y1,y2){
				var width = (y1==undefined)? "400px" : toEn(y1.replace(/px/,""))+"px";
				return "<div style='column-count:auto; column-width:"+width+"; column-gap:40px;'>"+y2+"</div>";
			})
			
			.replace(/(?:\/قاب)(?:\[([۰۱۲۳۴۵۶۷۸۹\d]+[٪\%]?(?:px)?)?([آقسزخط]?)\])?(?:[ \t\n]*\[[ \t\n]*([^\n]+?)[ \t\n]*\][ \t\n]*)?(?:\/)[ \t\n]*([\s\S]*?)[ \t\n]*(?:\/قاب\/)/g, function(x,y1,y2,y3,y4){
				var width=(y1==undefined)? "80%" 
						: (y1.indexOf("\%")!=-1 || y1.indexOf("٪")!=-1)? toEn(y1.replace(/[٪\%]/,""))+"%"
						: toEn(y1.replace(/(?:px)/,""))+"px";
				var colorBG, colorTitleBG; //ColorText="black";
				switch(y2){
					case "آ":
						colorBG="rgba(0,191,255,0.4)";
						colorTitleBG="rgba(30,144,255,0.4)";
						//ColorText="black";
						break;
					case "ق":
						colorBG="rgba(255,0,90,0.3)";
						colorTitleBG="rgba(255,0,90,0.5)";
						//ColorText="black";
						break;
					case "س":
						colorBG="rgba(154,205,50, 0.5)";
						colorTitleBG="rgba(50,205,50, 0.5)";
						//ColorText="black";
						break;
					case "ز":
						colorBG="rgba(255,255,0,0.5)";
						colorTitleBG="rgba(255,195,16,0.5)";
						//ColorText="black";
						break;
					case "ط":
						colorBG="rgba(255,215,0,0.5)";
						colorTitleBG="rgba(218,165,32,0.5)";
						//ColorText="black";
						break;
					case "خ":
						colorBG="rgba(200, 200, 200,0.5)";
						colorTitleBG="rgba(180,180,180,0.5)";
						//ColorText= "black";
						break;
					default:
						colorBG="rgba(255, 255, 255, 0.2)";
						colorTitleBG="rgba(255, 255, 255, 0.1)";
						//ColorText="black";
				}
				var headerTitle, headerTitleDisplay="";
				if(y3==undefined || y3=="|"){
					headerTitle="";
					headerTitleDisplay="none";
				}else{
					headerTitle=y3.replace(/\|/,"");
				}
				return "<div style='margin:auto; width:"+width+"; background-color:"+colorBG+"; border-radius:10px;'>"
						+"<div style='display:"+headerTitleDisplay+"; width:100%; background-color:"+colorTitleBG+"; border-radius:10px 10px 0 0; padding:10px; font-size:120%;'>"
							+headerTitle
						+"</div>"
						+"<div style='padding:10px;'>"+y4+"</div>"
					+"</div>";
			})
			
			.replace(/(\/ی\/)[ \t]*([\s\S]*?)[ \t]*\1/g,"<!-- $2 -->")
			
			
			// for capturing the title and subtitle of the notebook (the main title will be used as name of the file)
			.replace(/(?:\/عنوان\/)[ \t]*(.+)[ \t]*/g,"<div id='titleWrapper'><span id='title'>$1</span></div>")	//   "<div id='titleWrapper'>«<span id='title'>$1</span>»</div>"
			.replace(/(?:\/زیرعنوان\/)[ \t]*(.+)[ \t]*/g,"<div id='subtitle'>$1</div>")
			
			
			// for capturing the date of the last revision: today, now
			.replace(/(?:\/تاریخ\/)/g,"<span id='today'></span>")
			
			
			// for capturing the name of the author
			.replace(/(?:\/نویسنده\/)[ \t]*(.+)[ \t]*/g,"<div id='author'>$1</div>")
			
			
			// for capturing the table of content
			.replace(/(\/فهرست\/)/g,"<div id='toc' onPage='"+pageNumVar+"'></div>")
			
			
			// for capturing "headings" in three levels "h1", "h2" ... to ... "h6"
			.replace(/(?:\/=۱\/)(?:\[[ \t]*([^\]]*)[ \t]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h1' onPage='"+pageNumVar+"' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۲\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h2' onPage='"+pageNumVar+"' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۳\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h3' onPage='"+pageNumVar+"' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۴\/)(?:\[[ \t]*([^\]]*)[ \t]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h4' onPage='"+pageNumVar+"' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۵\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h5' onPage='"+pageNumVar+"' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۶\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h6' onPage='"+pageNumVar+"' key='"+key+"'>"
							+y2
						+"</div>";
			})
			
			
			//for capturing links ...
			.replace(/(?:\/لینک)(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\[([^\]]*)\])?/g,"<a href='$2' title='$3'>$1</a>")   //use as   /لینک{متن}{http://www.address.com}[عنوان]
			//for capturing email links ...
			.replace(/(?:\/ایمیل)(?:\{[ \t]*([^\}]*)[ \t]*\})/g,"<a href='mailto:$1'>$1</a>")   //use as   /ایمیل{aaaa_bbbb@ccc.ir}
			
			// to generate "لنگرگاه" everywhere the user will refer to later ... 	//use as   /لنگرگاه{key}
			.replace(/(?:\/لنگرگاه)(?:\{[ \t]*(.*?)[ \t]*\})/g, "<span id='anchor-$1' onPage='"+pageNumVar+"'></span>")
			
			
			// Bold, Italic, Underline, Linetrough, ...
			.replace(/(\×\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<strong>$2</strong>")
			.replace(/(\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<em>$2</em>")
			.replace(/(\/ـ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<u>$2</u>")
			.replace(/(\/-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<s>$2</s>")
					
			.replace(/(\/،\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<sub>$2</sub>")
			.replace(/(\/٬\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<sup>$2</sup>")
			
			.replace(/(\/ق\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(220,20,60)'>$2</span>")
			.replace(/(\/آ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(0,0,139)'>$2</span>")
			.replace(/(\/س\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:darkgreen'>$2</span>")
			.replace(/(\/ط\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(189,158,85)'>$2</span>")
			
			.replace(/(\/زرد\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:yellow'>$2</span>")
			.replace(/(\/سبز\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:lime'>$2</span>")
			
			.replace(/(\/ف۱\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en1, fa1; font-size:100%;'>$2</span>")
			.replace(/(\/ف۲\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en5, fa2; font-size:105%;'>$2</span>")
			.replace(/(\/ف۳\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa3; font-size:110%;'>$2</span>")
			.replace(/(\/ف۴\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en4, fa4; font-size:130%;'>$2</span>")
			.replace(/(\/ف۵\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en4, fa5; font-size:150%; line-height:120%;'>$2</span>")
			.replace(/(\/ف۶\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en2, fa6; font-size:140%; line-height:190%;'>$2</span>")
			.replace(/(\/ف۷\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en3, fa7; font-size:100%;'>$2</span>")
			.replace(/(\/ف۸\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en1, fa8; font-size:170%;'>$2</span>")
			.replace(/(\/f1\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en1; font-size:100%;'>$2</span>")
			.replace(/(\/f2\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en2, fa6; font-size:170%; line-height:140%;'>$2</span>")
			.replace(/(\/f3\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en3, fa7; font-size:100%;'>$2</span>")
			.replace(/(\/f4\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en4, fa4; font-size:140%;'>$2</span>")
			.replace(/(\/f5\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en5, fa2; font-size:130%;'>$2</span>")
			.replace(/(\/f6\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en6, fa5; font-size:120%;'>$2</span>")
			.replace(/(\/f7\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en7; font-size:120%;'>$2</span>")
			.replace(/(\/f8\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en8; font-size:140%;'>$2</span>")
			
			.replace(/(\/قرآن\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa3; font-size:110%; color:rgb(34,139,34); text-shadow:2px 2px 4px white;'>$2</span>")
			.replace(/(\/حدیث\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa2; font-size:97%; color:rgb(65,105,225); text-shadow:2px 2px 4px white;'>$2</span>")
			.replace(/(\/ترجمه\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa7; font-size:90%; color:rgb(205,92,92); text-shadow:2px 2px 4px white;'>$2</span>")
			
			
			.replace(/(?:\/ب([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\/ب\//g, function(x,y1,y2){
				return "<span style='font-size:calc( 100% *"+toEn(y1.replace(/[\/٫٬]/,"."))+" );'>"+y2+"</span>";
			})
			
			
			.replace(/(\/چ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span class='blink'> $2 </span>")
			.replace(/(\/\+\-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span class='growShrink'> $2 </span>")
			.replace(/(\/\@\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g, "<span class='vibrotate'>$2</span>")
			.replace(/(\/\@\-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g, function(x,y1,y2){	// to rotate, word by word
				y2=y2.replace(/([^\s\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+|[\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+)/g,
								"<span class='vibrotate'>$1</span>");
				return y2;
			})
			.replace(/(\/\^\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span class='alert'> $2 </span>")
			
			
			
			// font coloring: transparent font on a colorful background
			.replace(/(?:\/ر([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/ر\/)/g,"<span class='colorfulFontBG-$1'> $2 </span>")
			.replace(/(?:\/رر([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/رر\/)/g,"<span class='colorfulFontBG-$1 Anim'> $2 </span>")
			// font coloring: word by word
			.replace(/(?:\/رـ([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/رـ\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|([^\s\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+|[\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+)/g, function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFont-"+y1+"'>"+y2+"</span>";
			})
			.replace(/(?:\/ررـ([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/ررـ\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|([^\s\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+|[\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+)/g,function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFontAnim-"+y1+"'>"+y2+"</span>";
			})
			// font coloring: char by char
			.replace(/(?:\/ر-([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/ر-\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|(\s|\S)/g,function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFont-"+y1+"'>"+y2+"</span>";
			})
			.replace(/(?:\/رر-([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/رر-\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|(\s|\S)/g,function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFontAnim-"+y1+"'>"+y2+"</span>";
			})
			
			
			
			// for typing effect in the presentation mode, use it by the command /ت؟/.../ت/
			.replace(/(?:\/ت([\d۰-۹]+)?\/)(?=\S)([^\r]*?\S)(?:\/ت\/)/g, function(x,y1,y2){
				var speed=(y1!=undefined)? toEn(y1) : "75";
				return "<span class='typingEffect' speed='"+speed+"'>"+y2+"</span>";
			})
			
			
			
			.replace(/(?:\/بلوک([۰۱۲۳۴۵۶۷۸۹\d]+[\%٪]?)?\{)(?:[ \t\n]*([+-]?[۰۱۲۳۴۵۶۷۸۹\d]+(?:px)?|[بپو])\|)?[ \t\n]*([\s\S]*?)[ \t\n]*(?:\})/g, function(x,y1,y2,y3){
				var width=(y1==undefined)? "300px" 
						: (y1.indexOf("\%")!=-1 || y1.indexOf("٪")!=-1)? toEn(y1.replace(/[٪\%]/,""))+"%"
						: toEn(y1.replace(/px/,""))+"px";
				var vposition=(y2==undefined)? "middle"
						: (y2.indexOf("ب")!=-1)? "bottom"
						: (y2.indexOf("و")!=-1)? "middle"
						: (y2.indexOf("پ")!=-1)? "top"
						: toEn(y2.replace(/px/,""))+"px";
				//alert(width+" ; "+vposition);
				return "<div style='display:inline-block; max-width:"+width+"; vertical-align:"+vposition+";'>"+y3+"</div>";
			})
			
			.replace(/^[ \t]*(---)[ \t]*$/gm,"<hr>")
			.replace(/^[ \t]*(===)[ \t]*$/gm,"<hr style='border:0px; border-top:5px double #8c8c8c;'>")
			
			.replace(/[ \t]*\n{0,1}(\/=.\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:left; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:right; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/=.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:center; margin:0;'>$2</p>")
			
			
			.replace(/(\/ltr\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span dir='ltr'>$2</span>")
			.replace(/[ \t]*\n{0,1}(\/ltrp\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p dir='ltr' style='text-align:justify;'>$2</p>")
			
			
			.replace(/(?:\/پ([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)(\%|\٪)?\/)/g, function(x,y1,y2){
				var inEn=toEn(y1);
				var marginTop = (y2!=undefined)? inEn+"vh" : inEn+"px";
				return "<div style='display:block!important; margin-top:"+marginTop+";'></div>";
			})
			.replace(/(?:\/ج([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)\/)/g, function(x,y){
				return " <span style='margin-right:"+toEn(y)+"px;'></span>";
			})
			
			.replace(/(?:\/ج\/)(.+?\n)/g, function(x,y){
				var temp=1, yt=y, ytt="";
				while(temp){
					ytt=yt.replace(/(?:\/ج\/)(.+?\n)/g, "<div style='margin:0 40px 0 0;'>$1</div>");
					if(ytt==yt){temp=0;}
					yt=ytt;
				}
				return "<div style='margin:0 40px 0 0;'>"+ytt+"</div>";
			})
			.replace(/(?:\/ع\/)(.+?\n)/g, function(x,y){
				var temp=1, yt=y, ytt="";
				while(temp){
					ytt=yt.replace(/(?:\/ع\/)(.+?\n)/g, "<div style='position:relative; margin:0 -40px 0 0;'>$1</div>");
					if(ytt==yt){temp=0;}
					yt=ytt;
				}
				return "<div style='position:relative; margin:0 -40px 0 0;'>"+ytt+"</div>";
			})
			
			
			.replace(/٪٪[ \t\n]*([\s\S]*?)[ \t\n]*٪٪/g,"<pre dir='ltr'><code style='background:none;'>$1</code></pre>")  //"<pre><code>$1</code></pre>" this enters code in a newline
			.replace(/٪(.*?)٪/g,"<code dir='ltr'>$1</code>")  //"<pre><code>$1</code></pre>" this enters code in a newline
			
			.replace(/\%/g,"%")
			.replace(/\/\%/g,"٪")
			;
	return string;
}
function parseReferences(string){
	string=string
			// for capturing citation to references, each reference had been given a key before ...
			//use as  /ارجاع[description]{key}   or   /ارجاع{key}   if the citations doesn't need further description
			.replace(/(?:\/ارجاع)(?:\[[ \t]*(.*?)[ \t]*\]*)?(?:\{[ \t]*(.*?)[ \t]*\})/g,function (x,y1,y2) {
				y1=(y1!=undefined)? y1.replace(/(--)/g,"&#8211;") : "";
				return "<my-citation description='"+y1+"'>"+y2+"</my-citation>";
			})
			
				
			// for capturing definition of the references, each reference should at least have a key and the body data
			// use it as /مرجع{کلید}[نویسندگان: ...][عنوان: ...][ناشر: ...][سال: ..][توضیحات: ...][خلاصه: ...][زبان: ...]
			// although each [] is optional ...	
			.replace(/[ \t\n]*(?:\/مرجع)(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t\n]*(?:\[نویسندگان:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[عنوان:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[ناشر:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[سال:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[توضیحات:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[خلاصه:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[زبان:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*/g, function(x,y1,y2,y3,y4,y5,y6,y7,y8){
				var key=(y1!=undefined)? y1 : "" ;
				var author="", title="", publisher="", year="", comment=""; 	// "&mdash;"
				var shortRef=(y7!=undefined)? y7 : "" ;
				var lang=(y8!=undefined)? y8 : "" ;
				
				if(y2!=undefined){
					//y2=parseStyles(y2);
					//y2=parseTables(y2);
					//y2=parseFigures(y2);
					//y2=parseVideos(y2);
					//y2=parseAudios(y2);
					//y2=parseiFrames(y2);
					//y2=parseFootnotes(y2);
					y2=parseListItems(y2);
					//y2=parsePresentationItems(y2);
					y2=parseEnvironments(y2);
					//y2=parseReferences(y2);
					//y2=parseSymbols(y2);
					y2=y2.replace(/(--)/g,"&#8211;");	// &ndash;
					author=y2;
				}
				if(y3!=undefined){
					//y3=parseStyles(y3);
					//y3=parseTables(y3);
					//y3=parseFigures(y3);
					//y3=parseVideos(y3);
					//y3=parseAudios(y3);
					//y3=parseiFrames(y3);
					//y3=parseFootnotes(y3);
					y3=parseListItems(y3);
					//y3=parsePresentationItems(y3);
					y3=parseEnvironments(y3);
					//y3=parseReferences(y3);
					//y3=parseSymbols(y3);
					title=y3;
				}
				if(y4!=undefined){
					//y4=parseStyles(y4);
					//y4=parseTables(y4);
					//y4=parseFigures(y4);
					//y4=parseVideos(y4);
					//y4=parseAudios(y4);
					//y4=parseiFrames(y4);
					//y4=parseFootnotes(y4);
					y4=parseListItems(y4);
					//y4=parsePresentationItems(y4);
					y4=parseEnvironments(y4);
					//y4=parseReferences(y4);
					//y4=parseSymbols(y4);
					publisher=y4;
				}
				if(y5!=undefined){
					//y5=parseStyles(y5);
					//y5=parseTables(y5);
					//y5=parseFigures(y5);
					//y5=parseVideos(y5);
					//y5=parseAudios(y5);
					//y5=parseiFrames(y5);
					//y5=parseFootnotes(y5);
					y5=parseListItems(y5);
					//y5=parsePresentationItems(y5);
					y5=parseEnvironments(y5);
					//y5=parseReferences(y5);
					//y5=parseSymbols(y5);
					year=y5;
				}
				if(y6!=undefined){
					//y6=parseStyles(y6);
					//y6=parseTables(y6);
					//y6=parseFigures(y6);
					//y6=parseVideos(y6);
					//y6=parseAudios(y6);
					//y6=parseiFrames(y6);
					//y6=parseFootnotes(y6);
					y6=parseListItems(y6);
					//y6=parsePresentationItems(y6);
					y6=parseEnvironments(y6);
					//y6=parseReferences(y6);
					//y6=parseSymbols(y6);
					y6=y6.replace(/(--)/g,"&#8211;");	// &ndash;
					comment=y6;
				}
				
				return "<my-references  key=\""+key+"\"  author=\""+author+"\"  title=\""+title+"\"  publisher=\""+publisher+"\"  year=\""+year+"\"  comment=\""+comment+"\"  shortRef=\""+shortRef+"\" language=\""+lang+"\" style=\"display:none;\"></my-references>";
			})
			// for containing the list of references
			.replace(/(\/مراجع\/)/g,"<div id='listOfReferences' onPage='"+pageNumVar+"'></div>")
			.replace(/(\/مراجع\*\/)/g,"<div id='listOfReferences' onPage='"+pageNumVar+"' ordered='true'></div>");
	return string;
}
function parseSymbols(string) {
	string=string
			.replace(/(\(بسمله\))/g,"<span style='font-family:fa5; font-size:140%;'>‌بِسْــمِ <span style='color:rgb(220,20,60)'>اللَّـهِ</span> الرَّحْمـٰنِ الرَّحِيمِ</span>")
			.replace(/(\(بسمله۱\))/g,"<span style='font-family:sardar;'>‌ا</span>")
			.replace(/(\(بسمله۲\))/g,"<span style='font-family:sardar;'>‌ب</span>")
			.replace(/(\(بسمله۳\))/g,"<span style='font-family:sardar;'>‌پ</span>")
			.replace(/(\(بسمله۴\))/g,"<span style='font-family:sardar;'>‌ت</span>")
			.replace(/(\(بسمله۵\))/g,"<span style='font-family:sardar;'>‌ث</span>")
			
			.replace(/(\(جل\*\))/g,"<span style='font-family:fa4'>«جَلَّ‌جَلالُه»</span>")
			.replace(/(\(جل\))/g,"<span style='font-family:sardar'>ح</span>")
			
			.replace(/(\(ص\*\))/g,"<span style='font-family:fa4'>«صَلَّی‌اللّه‌ُعَلَیْه‌ِوَآلِه»</span>")
			.replace(/(\(ص\))/g,"<span style='font-family:sardar'>ج</span>")
			.replace(/(\(ص\-\))/g,"<span style='font-family:sardar'>ط</span>")
			
			.replace(/(\(علیه\*\))/g,"<span style='font-family:fa4'>«عَلَیْه‌ِالسَّلام»</span>")
			.replace(/(\(علیه\))/g,"<span style='font-family:sardar'>خ</span>")
			
			.replace(/(\(علیها\*\))/g,"<span style='font-family:fa4'>«عَلَیْهاالسَّلام»</span>")
			.replace(/(\(علیها\))/g,"<span style='font-family:sardar'>د</span>")
			
			.replace(/(\(علیهما\*\))/g,"<span style='font-family:fa4'>«عَلَیْهِماالسَّلام»</span>")
			.replace(/(\(علیهما\))/g,"<span style='font-family:sardar'>ذ</span>")
			
			.replace(/(\(علیهم\*\))/g,"<span style='font-family:fa4'>«عَلَیْهِم‌ُالسَّلام»</span>")
			.replace(/(\(علیهم\))/g,"<span style='font-family:sardar'>ر</span>")
			
			.replace(/(\(عج\*\))/g,"<span style='font-family:fa4'>«عَجّ‌َاللّه‌ُفَرَجَه‌ُالشَّریف»</span>")
			.replace(/(\(عج\))/g,"<span style='font-family:sardar'>ظ</span>")
			.replace(/(\(عج\-\))/g,"<span style='font-family:sardar'>ی</span>")
			
			.replace(/(\(رحمه\*\))/g,"<span style='font-family:fa4'>«رَحِمَه‌ُاللّه»</span>")
			.replace(/(\(رحمه\))/g,"<span style='font-family:sardar'>ز</span>")
			
			.replace(/(\(رحمها\*\))/g,"<span style='font-family:fa4'>«رَحِمَهااللّه»</span>")
			.replace(/(\(رحمها\))/g,"<span style='font-family:sardar'>س</span>")
			
			.replace(/(\(رحمهما\*\))/g,"<span style='font-family:fa4'>«رَحِمَهُمااللّه»</span>")
			.replace(/(\(رحمهما\))/g,"<span style='font-family:sardar'>ش</span>")
			
			.replace(/(\(رحمهم\*\))/g,"<span style='font-family:fa4'>«رَحِمَهُم‌ُاللّه»</span>")
			.replace(/(\(رحمهم\))/g,"<span style='font-family:sardar'>ص</span>")
		
		// شکلک‌ها (smiley)
			.replace(/(\/ش۱\/)/g, "<img src='Main/images/smiley/1.gif' style='margin-bottom:-3px;'>")	
			.replace(/(\/ش۲\/)/g, "<img src='Main/images/smiley/2.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۳\/)/g, "<img src='Main/images/smiley/3.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴\/)/g, "<img src='Main/images/smiley/4.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵\/)/g, "<img src='Main/images/smiley/5.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶\/)/g, "<img src='Main/images/smiley/6.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۷\/)/g, "<img src='Main/images/smiley/7.gif' style='margin-bottom:-7px;'>")
			.replace(/(\/ش۸\/)/g, "<img src='Main/images/smiley/8.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۹\/)/g, "<img src='Main/images/smiley/9.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۰\/)/g,"<img src='Main/images/smiley/10.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۱۱\/)/g,"<img src='Main/images/smiley/11.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۲\/)/g,"<img src='Main/images/smiley/12.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۱۳\/)/g,"<img src='Main/images/smiley/13.gif' style='margin-bottom:-9px;'>")
			.replace(/(\/ش۱۴\/)/g,"<img src='Main/images/smiley/14.gif' style='margin-bottom:-8px;'>")
			.replace(/(\/ش۱۵\/)/g,"<img src='Main/images/smiley/15.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۶\/)/g,"<img src='Main/images/smiley/16.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۱۷\/)/g,"<img src='Main/images/smiley/17.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۸\/)/g,"<img src='Main/images/smiley/18.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۹\/)/g,"<img src='Main/images/smiley/19.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۲۰\/)/g,"<img src='Main/images/smiley/20.gif' style='margin-bottom:-4px;'>")		
			.replace(/(\/ش۲۱\/)/g, "<img src='Main/images/smiley/21.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۲\/)/g, "<img src='Main/images/smiley/22.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۲۳\/)/g, "<img src='Main/images/smiley/23.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۴\/)/g, "<img src='Main/images/smiley/24.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۵\/)/g, "<img src='Main/images/smiley/25.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۲۶\/)/g, "<img src='Main/images/smiley/26.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۲۷\/)/g, "<img src='Main/images/smiley/27.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۸\/)/g, "<img src='Main/images/smiley/28.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۲۹\/)/g, "<img src='Main/images/smiley/29.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۳۰\/)/g,"<img src='Main/images/smiley/30.gif' style='margin-bottom:-7px;'>")
			.replace(/(\/ش۳۱\/)/g,"<img src='Main/images/smiley/31.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۳۲\/)/g,"<img src='Main/images/smiley/32.gif' style='height:40px; margin-bottom:-8px;'>")
			.replace(/(\/ش۳۳\/)/g,"<img src='Main/images/smiley/33.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۳۴\/)/g,"<img src='Main/images/smiley/34.gif' style='height:75px; margin-bottom:-8px;'>")
			.replace(/(\/ش۳۵\/)/g,"<img src='Main/images/smiley/35.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۳۶\/)/g,"<img src='Main/images/smiley/36.gif' style='margin-bottom:-7px;'>")
			.replace(/(\/ش۳۷\/)/g,"<img src='Main/images/smiley/37.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۳۸\/)/g,"<img src='Main/images/smiley/38.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۳۹\/)/g,"<img src='Main/images/smiley/39.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۰\/)/g,"<img src='Main/images/smiley/40.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۴۱\/)/g,"<img src='Main/images/smiley/41.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۴۲\/)/g,"<img src='Main/images/smiley/42.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۳\/)/g,"<img src='Main/images/smiley/43.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۴۴\/)/g,"<img src='Main/images/smiley/44.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۵\/)/g,"<img src='Main/images/smiley/45.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۴۶\/)/g,"<img src='Main/images/smiley/46.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۷\/)/g,"<img src='Main/images/smiley/47.gif' style='height:40px; margin-bottom:-5px;'>")
			.replace(/(\/ش۴۸\/)/g,"<img src='Main/images/smiley/48.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۴۹\/)/g,"<img src='Main/images/smiley/49.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۰\/)/g,"<img src='Main/images/smiley/50.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۵۱\/)/g,"<img src='Main/images/smiley/51.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۲\/)/g,"<img src='Main/images/smiley/52.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۵۳\/)/g,"<img src='Main/images/smiley/53.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۵۴\/)/g,"<img src='Main/images/smiley/54.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۵\/)/g,"<img src='Main/images/smiley/55.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۵۶\/)/g,"<img src='Main/images/smiley/56.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۷\/)/g,"<img src='Main/images/smiley/57.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۸\/)/g,"<img src='Main/images/smiley/58.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۵۹\/)/g,"<img src='Main/images/smiley/59.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۰\/)/g,"<img src='Main/images/smiley/60.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۱\/)/g,"<img src='Main/images/smiley/61.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۲\/)/g,"<img src='Main/images/smiley/62.gif' style='margin-bottom:-2px;'>")
			.replace(/(\/ش۶۳\/)/g,"<img src='Main/images/smiley/63.gif' style='margin-bottom:-2px;'>")
			.replace(/(\/ش۶۴\/)/g,"<img src='Main/images/smiley/64.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۵\/)/g,"<img src='Main/images/smiley/65.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۶۶\/)/g,"<img src='Main/images/smiley/66.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۶۷\/)/g,"<img src='Main/images/smiley/67.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۶۸\/)/g,"<img src='Main/images/smiley/68.gif' style='height:36px; margin-bottom:-6px;'>")
			.replace(/(\/ش۶۹\/)/g,"<img src='Main/images/smiley/69.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۷۰\/)/g,"<img src='Main/images/smiley/70.gif' style='height:36px; margin-bottom:-5px;'>")
			.replace(/(\/ش۷۱\/)/g,"<img src='Main/images/smiley/71.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۷۲\/)/g,"<img src='Main/images/smiley/72.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۷۳\/)/g,"<img src='Main/images/smiley/73.gif' style='margin-bottom:-9px;'>")
			.replace(/(\/ش۷۴\/)/g,"<img src='Main/images/smiley/74.gif' style='height:36px; margin-bottom:-6px;'>")
			.replace(/(\/ش۷۵\/)/g,"<img src='Main/images/smiley/75.gif' style='height:45px; margin-bottom:-6px;'>")
			
			.replace(/(\/؟\/)/g,"<img src='Main/images/smiley/ex1.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/!\/)/g,"<img src='Main/images/smiley/ex2.gif' style='height:21px; margin-bottom:-4px;'>")
			.replace(/(\/چپ\/)/g,"<img src='Main/images/smiley/ex3.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/راست\/)/g,"<img src='Main/images/smiley/ex4.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/لامپ\/)/g,"<img src='Main/images/smiley/ex5.gif' style='height:21px; margin-bottom:-3px;'>")
			.replace(/(\/شمع\/)/g,"<img src='Main/images/smiley/ex6.gif' style='height:21px; margin-bottom:-2px;'>")
			.replace(/(\/گل\/)/g,"<img src='Main/images/smiley/ex7.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/قلب\/)/g,"<img src='Main/images/smiley/ex8.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/بادکنک\/)/g,"<img src='Main/images/smiley/ex9.gif' style='height:26px; margin-bottom:-2px;'>")
			.replace(/(\/کبوتر\/)/g,"<img src='Main/images/smiley/ex10.gif' style='height:26px; margin-bottom:-2px;'>")
			.replace(/(\/پروانه\/)/g,"<img src='Main/images/smiley/ex11.gif' style='height:21px; margin-bottom:-4px;'>")
			.replace(/(\/قهوه\/)/g,"<img src='Main/images/smiley/ex12.gif' style='height:21px; margin-bottom:-2px;'>")
			
			.replace(/(\/خط۱\/)/g,"<img src='Main/images/glyph/1.svg' style='width:500px; margin-bottom:0px;'>")
			.replace(/(\/خط۲\/)/g,"<img src='Main/images/glyph/2.svg' style='width:90px; margin-bottom:-5px;'>")
			.replace(/(\/خط۳\/)/g,"<img src='Main/images/glyph/3.svg' style='width:250px; margin-bottom:-5px;'>")
			.replace(/(\/خط۴\/)/g,"<img src='Main/images/glyph/4.svg' style='width:180px; margin-bottom:-5px;'>")
			.replace(/(\/خط۵\/)/g,"<img src='Main/images/glyph/5.svg' style='width:150px; margin-bottom:-5px;'>")
			.replace(/(\/خط۶\/)/g,"<img src='Main/images/glyph/6.svg' style='width:200px; margin-bottom:-15px;'>")
			.replace(/(\/خط۷\/)/g,"<img src='Main/images/glyph/7.svg' style='width:150px; margin-bottom:-5px;'>")
			.replace(/(\/خط۸\/)/g,"<img src='Main/images/glyph/8.svg' style='width:200px; margin-bottom:-5px;'>")
			.replace(/(\/خط۹\/)/g,"<img src='Main/images/glyph/9.svg' style='width:180px; margin-bottom:-5px;'>")
			.replace(/(\/خط۱۰\/)/g,"<img src='Main/images/glyph/10.svg' style='width:180px; margin-bottom:-5px;'>")
			.replace(/(\/خط۱۱\/)/g,"<img src='Main/images/glyph/11.svg' style='width:180px; margin-bottom:-15px;'>")
	return string;
}



// -----------------------------------------------------------------------------
// defining function for resizing the "source" and "result" divs, interactively ...

/*
var observer = new MutationObserver(function(mutations) {
	resultWrapper.style.width =  'calc(100% - '+ (source.style.width) +' - 5px)';
});
observer.observe(source, {attributes: true});
*/
dragElement(document.getElementById("draggablePaneSeparator"));
function dragElement(el){
	el.onmousedown = function(ev){
		ev = ev || window.event;
		ev.preventDefault();
		
		document.onmouseup = function(){	// stop moving when mouse button is released
			document.onmouseup = null;
			document.onmousemove = null;
		};
		document.onmousemove =  function(e){
			e = e || window.event;
			e.preventDefault();
			
			if(e.screenX<=10){
				source.style.display =  'initial';
				el.style.left = '3px';
				source.style.width =  'calc(100% - 5px)';
				resultWrapper.style.display =  'none';
			}else if(e.screenX>=(window.innerWidth-25)){
				resultWrapper.style.display =  'initial';
				el.style.left = (window.innerWidth-10)+'px';
				resultWrapper.style.width =  'calc(100% - 5px)';
				source.style.display =  'none';
			}else{
				source.style.display =  'initial';
				resultWrapper.style.display =  'initial';
				el.style.left = 'calc('+ (e.screenX) +'px)';
				resultWrapper.style.width =  'calc('+ el.style.left +' - 5px)';
				source.style.width =  'calc(100% - '+ (resultWrapper.style.width) +' - 5px)';
			}
			
			
		};
	};
}



// -----------------------------------------------------------------------------
// defining function for alteration of direction of input from RTL to LTR and vice versa ...


function changeDirection(){
	RTLVar=(RTLVar)? 0 : 1 ;
	if(RTLVar){
		source.dir="rtl";
		document.getElementById("RTLorLTR").src="Main/images/rtl.png";
		document.getElementById("RTLorLTR").title="برای نوشتن از چپ به راست فشار دهید";
		//source.style.cssFloat="right";
		//result.style.cssFloat="left";
	}else{
		source.dir="ltr";
		document.getElementById("RTLorLTR").src="Main/images/ltr.png";
		document.getElementById("RTLorLTR").title="برای نوشتن از راست به چپ فشار دهید";
		//source.style.cssFloat="left";
		//result.style.cssFloat="right";
	}
};


// -----------------------------------------------------------------------------
// SIMPLE scroller Syncing between the "source" box and the "result box"
source.ondblclick = function(){
	// ---- to sync the two pains linearly with numbers
	//result.scrollTop = source.scrollTop;

	// ---- to sync the two pains linearly in percent of their own hieght
	var scrollPositionPercent_Source=source.scrollTop/(source.scrollHeight - source.clientHeight);
	result.scrollTop=(result.scrollHeight - result.clientHeight)*scrollPositionPercent_Source;
}
result.ondblclick = function(){
	// ---- to sync the two pains linearly with numbers
	//source.scrollTop = result.scrollTop;

	// ---- to sync the two pains linearly in percent of their own hieght
	var scrollPositionPercent_Result=result.scrollTop/(result.scrollHeight - result.clientHeight);
	source.scrollTop=(source.scrollHeight - source.clientHeight)*scrollPositionPercent_Result;
}



// -----------------------------------------------------------------------------
// open file


var openFile=document.getElementById("Openfile");

function openFunction(){
	if(window.localStorage["TextEditorData"] != ""){
		if(!confirm('با باز کردن فایل جدید ورودی‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	openFile.click();	// this opens the file browser dialog for selecting a file to open
	return;
};

openFile.addEventListener('change', function() {
	var fileToLoad=openFile.files[0];			// the selected file itself as an object?
	var fileToLoadAddress=openFile.value;		// the relative or absolute address of the selected file
	
	document.getElementById("fileName").innerHTML="<span style='color:white; text-shadow: 2px 2px 2px black;''>عنوان فایل: </span><span style='color:orange; text-shadow: 1px 1px 1px black; font-size:16px;'>"
							+fileToLoadAddress  .split('\\').pop()  .replace(/(.txt)/,"")	.replace(/\./,":")
    					+"</span>";
	
	if(fileToLoad){
		var reader=new FileReader();
		reader.readAsText(fileToLoad, "UTF-8");
		reader.onload=function(event){
			sourceContent = event.target.result.split(" <NEWPAGE> ");
			result.innerHTML="";
			totalPageNumber = sourceContent.length;
			currentPage = 0;
			changePage();
		};
		reader.onerror=function(event){ source.value="بارگذاری فایل انتخاب شده ناموفق بود!"; };
	}
});



// -----------------------------------------------------------------------------
// Drag&Drop text file into the siurce textarea to open the file's content there
// got the inspiration from "http://devjs.eu/en/drag-multiple-text-files-to-your-web-application-with-html5-and-javascript/"


source.addEventListener('dragover', dragOver);
source.addEventListener('dragend', dragEnd);
source.addEventListener('drop', readText, false);

function dragOver(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	//e.dataTransfer.effectAllowed = "move";		// when the curser changed, the file can be dropped!
	return false;
}
function dragEnd(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	return false;
}
function readText(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	
	var fileData, reader, file=e.dataTransfer.files[0];
	if (!file) {return false;}
	
	if(localStorage.getItem("TextEditorData") !== null && JSON.stringify(localStorage["TextEditorData"]).replace(/\"\"/g,"") != ""){
		if(!confirm('با باز کردن فایل جدید ورودی‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
    
    //to read the content of the file
    reader=new FileReader();
	reader.readAsText(file, "UTF-8");
	reader.onload=function(event){
		sourceContent = event.target.result.split(" <NEWPAGE> ");
		result.innerHTML="";
		totalPageNumber = sourceContent.length;
		currentPage = 0;
		changePage();
	}
	reader.onerror=function(event){ source.value="بارگذاری فایل انتخاب شده ناموفق بود!"; };
	
	//to read the file name and introduce it to the application
    document.getElementById("fileName").innerHTML="<span style='color:white; text-shadow: 2px 2px 2px black;''>عنوان فایل: </span><span style='color:orange; text-shadow: 1px 1px 1px black; font-size:16px;'>"
    						+ file.name  .split('\\').pop()  .replace(/(.txt)/,"")	.replace(/\./,":")
    					+"</span>";
}



// -----------------------------------------------------------------------------
// save the source file and the output as PDF, print the output as well



var today, title;

function saveSource(){
	today = (document.getElementById("today")==null)? "بدون تاریخ" : toFa(shortDate).replace(/\:/g,".");
	title = (document.getElementById("title")==null)? "بدون عنوان" :
				document.getElementById("title").textContent.length>24 ?
					document.getElementById("title").textContent.substring(0,20) + " ...":
						document.getElementById("title").textContent;
	
	// ------- if using  download.js
	download(sourceContentString ,
		title+" ("+today+").txt"  ,  "text/html");	// دانلود نتیجه‌ی خروجی را هم موقتی در برنامه گذاشتم که اگر یک وقت برنامه عوض شد و دستورهای نوشتن کدها عوض شدند اگر چیزی نوشته بودم لااقل خروجی موجود باشد و خروجی را هم می‌توان در ورودی وارد کرد و بجز فرمول‌ها که فقط بار اول که کامپایل شوند درست نشان می‌دهند سایر بخش‌ها درست اجرا می‌شود چون عملاً .replace()ها کاری رویشان نمی‌کنند ...
	
	// ------- if not using  download.js, but saving comment would be lame, e.g. colors are not saved and etc.
	//var a = document.body.appendChild(document.createElement("a"));
	//a.download = "myContacts.js";
	//a.href = "data:text/html," + aaData;
	//a.click();
};
function generateOutput(){
	if(htmlExport == undefined){
		alert("باید ابتدا حداقل یک بار کد ورودی را کامپایل نمایید!");
		return false;
	}
	title = (document.getElementById("title")==null)? "بدون عنوان" :
				document.getElementById("title").textContent.length>24 ?
					document.getElementById("title").textContent.substring(0,20) + " ...":
						document.getElementById("title").textContent;
	
	
	
	htmlExport=htmlExport	.replace(/(onclick\=\'currentPage\=[ \t]*\d+[ \t]*\; changePage\(\)\;\')/g, "")
				.replace(/(changePage\(\)\;)/g, "")
				.replace(/(class\=[\'\"]hidden[\'\"])/g, "");
	
	
	var myWindow = window.open("", "", "width=600,height=400,top=0,left=0,toolbar=yes");
	myWindow.document.write(
		'<!DOCTYPE html>\n'
		+'<html dir="rtl" lang="fa" class="htmlBackground" mozNoMarginBoxes>\n'
		+'<head>\n'
		+'	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />\n'
		+'	<meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
		+'	<title>'+title+'</title>\n'
		//+'	<link rel="icon" type="image/png" href="Main/images/icon.png">\n'	// I commented this out as it's a security bug in Firefox for more thatn 11 years that when the page is saved as "complete webpage", yet the logo (favicon) is not saved and is linked to the app's icon with complete address of the file, including the user's name in the coputer
		
		+'	<script type="text/javascript" src="Main/tex-config.js"></scr'+'ipt>\n'
		+'	<script type="text/javascript" src="Main/tex-svg-full.js" async></scr'+'ipt>\n'
		
		+'	<link type="text/css" rel="stylesheet" href="Main/myStyle.css"/>\n'
		+	userDefinedCSS
		+'</head>\n'
		+'<body style="padding:0px; margin-top:40;">\n'
		/*
		+'	<div style="position:fixed; float:left; top:0; left:0; border:solid 0px #000000; border-radius:5px; padding:1px 1px 1px 3px; background:rgba(0,0,0,0.3); z-index:1;" >\n'
		+'		<input id="saveHTML" class="myButton" onclick="saveHTML()" type="image" src="Main/images/html.png" alt=""  title="ذخیره‌ی خروجی به صورت HTML" align="center" width="27" style="display:block; position:relative; bottom:5%; padding:2px;">\n'
		+'		<input id="savePDF" class="myButton" onclick="savePDF()" type="image" src="Main/images/pdf.png" alt=""  title="ذخیره‌ی خروجی به صورت PDF" align="center" width="27" style="display:block; position:relative; bottom:5%; padding:2px;">\n'
		+'		<input id="Print" class="myButton" onclick="printResult()" type="image" src="Main/images/print.png" alt=""  title="چاپ کردن خروجی" align="center" width="27" style="display:block; position:relative; bottom:5%; padding:2px;">\n'
		+'	</div>\n'
		*/
		
		+'	<input id="endNotesSingleColButton" class="myButton" onclick="endNotesMultiCol()" type="image" src="Main/images/singleColumn.png" alt=""  title="برای نمایش توضیحات انتهایی در تنها یک ستون فشار دهید!" width="32" style="position:fixed; float:right; bottom:10px; right:5px;">\n'
		+'	<input id="endNotesMultiColButton" class="myButton" onclick="endNotesMultiCol()" type="image" src="Main/images/multiColumns.png" alt=""  title="برای نمایش توضیحات انتهایی به صورت چند ستونی (یک ستون به بالا، بسته به عرض صفحه) فشار دهید!" width="32" style="position:fixed; float:right; bottom:10px; right:5px; display:none;">\n'
		
		
		+'	<div id="FinalHtml" class="FinalHtml">\n'
		+		htmlExport
		+'\n	<div id="endNotes">\n'
		+'			<p class="header" kind="h1"><span class="header2Content">توضیحات</span></p><br>\n'
		+'\n		<div id="endNotesContent"></div>\n'
		+'		</div>\n'
		+'	</div>\n'
		
		+'	<input type="range" min="50" max="99" value="80" id="sizeSliderScript" style="position:fixed; float:right; top:-10px; right:0px; height:90px; background:rgba(0,0,0,0.3); outline:none; z-index:1; -webkit-appearance:slider-vertical; writing-mode:bt-lr;" orient="vertical"  title="تغییر اندازه‌ی بخش نمایش متن">\n'
		+'	<div id="toc_sideBar" class="toc_sideBar"></div>\n'
        +'	<button type="button" id="toc_button" class="myButton" style="display:none; position:fixed; float:right; top:25px; right:-5px; width:100px; height:40px; background:rgba(0,0,0,0.3); border-radius:8px; text-align:center; color:white; cursor:pointer; transform:rotate(-90deg); z-index:1;">فهرست مطالب</button>\n\n'
		
		+'	<script type="text/javascript">\n'
		
		+'	divFinalHtml=document.getElementById("FinalHtml");\n'
		+'	document.getElementById("sizeSliderScript").oninput = function() {\n'
		+'		divFinalHtml.style.width = "calc("+ Number(this.value) +"% - 25px)";\n'
		+'	}\n'
		
		+'	if(document.getElementById("toc")){\n'
		+'		document.getElementById("toc_button").style.display=\'\';\n'
		+'		document.getElementById("toc_sideBar").style.display=\'none\';\n'
		+'		document.getElementById("toc_sideBar").innerHTML+= document.getElementById("toc").innerHTML.replace(/(id\=\'H-)/g,"id\=\'NewH-");	// to put a copy of TOC inside the sidebar\n'
		+'		document.getElementById("toc_button").onclick = function() {\n'
		+'			document.getElementById("toc_button").style.display=\'none\';\n'
		+'			document.getElementById("toc_sideBar").style.display=\'\';\n'
		+'		}\n'
		+'		document.onclick = function(e){\n'
		+'			if(e.target.id != "toc_button" && e.target.id != "toc_sideBar"){\n'
		+'				document.getElementById("toc_button").style.display=\'\';\n'
		+'				document.getElementById("toc_sideBar").style.display=\'none\';\n'
		+'			}\n'
		+'		}\n'
		+'	}else{\n'
		+'		document.getElementById("toc_button").style.display=\'none\';\n'
		+'		document.getElementById("toc_sideBar").style.display=\'none\';\n'
		+'	}\n'
		
		+'	// footnotes -> endnotes ... first copy all the footnote sections at the end of pages into endnotes, then remove them\n'
		+'	[].map.call(document.querySelectorAll(\'*[id^="ftnColWrapperOnPage-"]\'), function(el){\n'
		+'		document.getElementById("endNotesContent").innerHTML+=el.innerHTML;\n'
		+'		el.parentNode.removeChild(el);\n'
		+'	});\n'
		+'	[].map.call(document.querySelectorAll(\'*[id^="ftnOnPage-"]\'), function(el){\n'
		+'		el.parentNode.removeChild(el);\n'
		+'	});\n'
		
		
		+'	EndNoteMultiColVar=1;\n'
		+'	function endNotesMultiCol(){\n'
		+'		if(EndNoteMultiColVar){\n'
		+'			EndNoteMultiColVar=0;\n'
		+'			document.getElementById("endNotesSingleColButton").style.display=\'none\';\n'
		+'			document.getElementById("endNotesMultiColButton").style.display=\'\';\n'
		+'			document.getElementById("endNotesContent").classList.add("singleFtnCol");\n'
		+'		}else{\n'
		+'			EndNoteMultiColVar=1;\n'
		+'			document.getElementById("endNotesSingleColButton").style.display=\'\';\n'
		+'			document.getElementById("endNotesMultiColButton").style.display=\'none\';\n'
		+'			document.getElementById("endNotesContent").classList.remove("singleFtnCol");\n'
		+'		}\n'
		+'	}\n'
		+'	if(document.getElementById("endNotesContent").innerHTML==""){\n'
		+'		document.getElementById("endNotes").style.display=\'none\';\n'
		+'		document.getElementById("endNotesSingleColButton").style.display=\'none\';\n'
		+'	}\n'


		+'	function tooltipRepositionCaller(id){\n'
		+'		var el=document.getElementById(id),\n'
		+'			elTooltip=document.getElementById(id+"-Hidden");\n'
		+'		tooltipReposition(el , elTooltip);\n'
		+'	}\n'
		+'	function tooltipReposition(el,eltt){\n'
		+'		var relativeLeft= el.getBoundingClientRect().left - divFinalHtml.getBoundingClientRect().left,\n'
		+'		relativeTop= el.getBoundingClientRect().top - divFinalHtml.getBoundingClientRect().top;\n'
		
		+'		var resultWrapperWidth=divFinalHtml.clientWidth,\n'
		+'			resultWrapperHeight=divFinalHtml.clientHeight;\n'
		
		+'		if(relativeTop <= Math.floor(resultWrapperHeight/2) && relativeLeft < Math.floor(resultWrapperWidth/3)){\n'
		+'			eltt.className = "tooltipContent bottomRight";\n'
		+'		}else if(relativeTop <= Math.floor(resultWrapperHeight/2) && relativeLeft > Math.floor(2*resultWrapperWidth/3)){\n'
		+'			eltt.className = "tooltipContent bottomLeft";\n'
		+'		}else if(relativeTop <= Math.floor(resultWrapperHeight/2)){\n'
		+'			eltt.className = "tooltipContent bottom";\n'
		+'		}else if(relativeTop > Math.floor(resultWrapperHeight/2) && relativeLeft < Math.floor(resultWrapperWidth/3)){\n'
		+'			eltt.className = "tooltipContent topRight";\n'
		+'		}else if(relativeTop > Math.floor(resultWrapperHeight/2) && relativeLeft > Math.floor(2*resultWrapperWidth/3)){\n'
		+'			eltt.className = "tooltipContent topLeft";\n'
		+'		}else{\n'
		+'			eltt.className = "tooltipContent top";\n'
		+'		}\n'
		+'	}\n'
						
		+'	</scr'+'ipt>\n'
		
		+'</body>\n'
		+'</html>'
	);
	
	
	//myWindow.focus();
	setTimeout(function(){ myWindow.stop(); }, 7000);	// assures that the windows stop loading after at most 7s
}



// -----------------------------------------------------------------------------
// prevent leaving the page


//$(window).bind('beforeunload', function(){
//	return 'شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید یادداشت‌های خود را در صورت تغییر ذخیره نمایید؟';
//});	
window.onbeforeunload = function() {
	return "توصیه بر ذخیره‌ی داده‌ها پیش از حروج از نرم‌افزار است ... آیا اطمینان دارید می‌خواهید از نرم‌افزار خارج شوید؟!";
}	
//window.addEventListener("beforeunload", function(event) {
//	event.returnValue = "شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید یادداشت‌های خود را در صورت تغییر ذخیره نمایید؟";
	//saveFunctioin();
//});
