window.MathJax = {
	options: {
		ignoreHtmlClass: 'virgin',	// not to search the divs with class 'virgin' for math
		enableMenu: true,			// set to false to disable the menu
		
		menuOptions: {
			settings: {
				zoom: 'DoubleClick',		// or 'NoZoom' or 'Click' as zoom trigger
				zscale: '200%',				// zoom scaling factor
			}
		}
	},
	section: 0,
	tex: {
		inlineMath: [ ["$","$"] ],		// ["$","$"],["\$","\$"],["\(","\)"],["\\(","\\)"]
		displayMath: [ ["$$","$$"] ],
		processEscapes: true,			// for \$ to mean a common dollar sign, not a math delimiter
		
		digits: /^(?:[\d۰-۹]+(?:[,٬'][\d۰-۹]{3})*(?:[\.\/٫][\d۰-۹]*)?|[\.\/٫][\d۰-۹]+)/,	// introduce numbers
		
		tagSide: "right",
		tagIndent: ".8em",
		multlineWidth: "85%",
		tags: "ams",
		packages: {'[+]': ['sections']},
		tagformat: {
			number: function(n){
				var N=(MathJax.config.section)?		n+'.'+MathJax.config.section	:	n;			// see https://github.com/mathjax/MathJax/issues/2427
				return String(N)
							.replace(/0/g,"۰").replace(/1/g,"۱").replace(/2/g,"۲").replace(/3/g,"۳")
							.replace(/4/g,"۴").replace(/5/g,"۵").replace(/6/g,"۶")
							.replace(/7/g,"۷").replace(/8/g,"۸").replace(/9/g,"۹");
			},
			id: (id) => 'mjx-eqn-' + id.replace(/\s/g, '_'),
			url:(id,base) => base + '#' + encodeURIComponent(id)
		}
	},
	svg: {
		fontCache: 'global',		// or 'local' or 'none'
		mtextInheritFont: true		// required to correctly render RTL Persian text inside a formula
	},
	startup: {
		ready() {
		
			// to add the persian digits as well to the digits MathJax understands
			var ParseMethods = MathJax._.input.tex.ParseMethods.default;
			var RegExpMap = MathJax._.input.tex.SymbolMap.RegExpMap;
			new RegExpMap('digit', ParseMethods.digit, /[\d.٫۰-۹]/);
			
			
			
			// for numbering the equations by Sectioning -- PreProcessing		(see https://github.com/mathjax/MathJax/issues/2427)
			const Configuration = MathJax._.input.tex.Configuration.Configuration;
			const CommandMap = MathJax._.input.tex.SymbolMap.CommandMap;
			new CommandMap('sections', {
					nextSection: 'NextSection'		// use it as \nextSection to increment the section number
				},
				{
					NextSection(parser, name) {
						MathJax.config.section++;
						parser.tags.counter = parser.tags.allCounter = 0;
					}
				}
			);
			Configuration.create(
				'sections', {handler: {macro: ['sections']}}
			);
			
			
			MathJax.startup.defaultReady();
			
			
			// for numbering the equations by Sectioning -- PostProcessing		(see https://github.com/mathjax/MathJax/issues/2427)
			MathJax.startup.input[0].preFilters.add(({math}) => {
				if (math.inputData.recompile) MathJax.config.section = math.inputData.recompile.section;
			});
			MathJax.startup.input[0].postFilters.add(({math}) => {
				if (math.inputData.recompile) math.inputData.recompile.section = MathJax.config.section;
			});
		
		}
	}
};
