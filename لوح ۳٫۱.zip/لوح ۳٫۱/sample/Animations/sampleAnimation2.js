var WIDTH2 = 320, HEIGHT2 = 240;
var renderer2, scene2, camera2, cube2;

function sampleAnimation2(){
       var container = document.getElementById("animation-"+"container2");

       renderer2 = new THREE.WebGLRenderer();
       renderer2.setSize(WIDTH2, HEIGHT2);
       container.appendChild(renderer2.domElement);

       camera2 = new THREE.PerspectiveCamera(45, WIDTH2 /HEIGHT2 , 0.1, 1000);
       scene2 = new THREE.Scene();
    
       scene2.add(camera2);
       camera2.position.z = 300;
    
       cube2 = new THREE.Mesh( new THREE.CubeGeometry(200, 200, 200) );
       cube2.position.y = 0;
       cube2.position.z = -150;
       scene2.add(cube2);
    
       requestAnimationFrame(render2);
};

function render2(){
      requestAnimationFrame(render2);
      
      cube2.rotation.x += 0.01;
      cube2.rotation.y -= 0.01;
      camera2.rotation.z += 0.005;
      
      renderer2.render(scene2, camera2);
};
