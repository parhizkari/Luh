window.MathJax = {
	loader: {
		load: ['tagFormat','color','boldsymbol','enclose','cancel','mhchem','action','html'],
		source: {'mhchem': 'mhchem.min.js'}
		
		// tagFormat: to manipulate equations' tags
		// color: defines \color , \colorbox, \fcolorbox, \definecolor; e.g. {\color{red} ...} 
		// boldsymbol: defines \boldsymbol{...} that produces a bold version of its argument
		// enclose: this one is required for "cancel"
		// cancel: defines \cancel{math} , \bcancel{math} , \xcancel{math} , \cancelto{value}{math}
		// html: gives access to some HTML features like styles, classes, element ID’s, and clickable links, by \style{css}{math} , \class{name}{math} , \cssId{id}{math} , \href{url}{math}
		// mhchem: implements the \ce{...} and \pu{...} chemical equation macros of the LaTeX mhchem package
		// action: it introduces the command "\toggle{}{}{}\endtoggle"
	},
	startup: {
		ready: function () {
			// to add the persian digits as well to the digits MathJax understands
			var ParseMethods = MathJax._.input.tex.ParseMethods.default;
			var RegExpMap = MathJax._.input.tex.SymbolMap.RegExpMap;
			new RegExpMap('digit', ParseMethods.digit, /[\d.٫۰-۹]/);
			
			// to define   MathJax.getAllJax()   function as a replacement for   MathJax.Hub.getAllJax()   in MathJax v.2
			MathJax.getAllJax = function(name){
				const list = Array.from(MathJax.startup.document.math);
				if (!name) return list;
				const container = document.getElementById(name);
				if (!container) return list;
				return list.filter((node) => container.contains(node.start.node));
			}
			return MathJax.startup.defaultReady();
		},
		
		// a temporary block of code to resolve a bug in using  "processEscapes: true"
		pageReady() {
			const options = MathJax.startup.document.options;
			const BaseMathItem = options.MathItem;
			options.MathItem = class FixedMathItem extends BaseMathItem {
				assistiveMml(document){
					if (this.display !== null) super.assistiveMml(document);
				}
			};
			return MathJax.startup.defaultPageReady();
		}
	},
	options: {
		renderActions: {
			//addMenu: []
		},
	},
	tex: {
		packages: {'[+]': ['tagFormat','color','boldsymbol','enclose','cancel','mhchem','action','html']},
		
		inlineMath: [ ["$","$"] ],		// ["$","$"],["\$","\$"],["\(","\)"],["\\(","\\)"]
		displayMath: [ ["$$","$$"] ],
		processEscapes: true,			// for \$ to mean a common dollar sign, not a math delimiter
		
		digits: /^(?:[\d۰-۹]+(?:[,٬'][\d۰-۹]{3})*(?:[\.\/٫][\d۰-۹]*)?|[\.\/٫][\d۰-۹]+)/,	// introduce numbers
		
		tagSide: "right",
		tagIndent: ".8em",
		multlineWidth: "85%",
		tags: "ams",
		tagFormat: {
			number: function(n){
				return String(n).replace(/0/g,"۰").replace(/1/g,"۱").replace(/2/g,"۲").replace(/3/g,"۳")
								.replace(/4/g,"۴").replace(/5/g,"۵").replace(/6/g,"۶")
								.replace(/7/g,"۷").replace(/8/g,"۸").replace(/9/g,"۹");
			}
		},
	},
	svg: {
		fontCache: 'global',		// or 'local' or 'none'
		mtextInheritFont: true,		// required to correctly render RTL Persian text inside a formula
		//scale: 0.97,				// global scaling factor for all expressions
		//displayAlign: 'center',	// default for indentalign when set to 'auto'
		//displayIndent: '0'		// default for indentshift when set to 'auto'
	},
};
