window.MathJax = {
	loader: {
		load: ['tagFormat','color','boldsymbol','enclose','cancel','mhchem','action','html'],
		source: {'mhchem': 'mhchem.min.js'}
		// tagFormat: to manipulate equations' tags
		// color: defines \color , \colorbox, \fcolorbox, \definecolor; e.g. {\color{red} ...} 
		// boldsymbol: defines \boldsymbol{...} that produces a bold version of its argument
		// enclose: this one is required for "cancel"
		// cancel: defines \cancel{math} , \bcancel{math} , \xcancel{math} , \cancelto{value}{math}
		// html: gives access to some HTML features like styles, classes, element ID’s, and clickable links, by \style{css}{math} , \class{name}{math} , \cssId{id}{math} , \href{url}{math}
		// mhchem: implements the \ce{...} and \pu{...} chemical equation macros of the LaTeX mhchem package
		// action: it introduces the command "\toggle{}{}{}\endtoggle"
	},
	startup: {
		ready: function () {
			// to add the persian digits as well to the digits MathJax understands
			var ParseMethods = MathJax._.input.tex.ParseMethods.default;
			var RegExpMap = MathJax._.input.tex.SymbolMap.RegExpMap;
			new RegExpMap('digit', ParseMethods.digit, /[\d.٫۰-۹]/);
			
			// to define   MathJax.getAllJax()   function as a replacement for   MathJax.Hub.getAllJax()   in MathJax v.2
			MathJax.getAllJax = function(name){
				const list = Array.from(MathJax.startup.document.math);
				if (!name) return list;
				const container = document.getElementById(name);
				if (!container) return list;
				return list.filter((node) => container.contains(node.start.node));
			}
			
			// to temporarily solve a bug in MathJax version 3.0.0 about tagFormat conflicts with AMS tags 
			var Configuration = MathJax._.input.tex.Configuration.Configuration;
			var TagsFactory = MathJax._.input.tex.Tags.TagsFactory;
			var tagFormatConfig = MathJax._.input.tex.tag_format.TagFormatConfiguration.tagFormatConfig;
			var TagformatConfiguration = MathJax._.input.tex.tag_format.TagFormatConfiguration.TagformatConfiguration;
			Configuration.create('tagFormat', {
				config: function (config, jax) {
					var tags = jax.parseOptions.options.tags;
					if (tags !== 'base' && config.tags.hasOwnProperty(tags)) {
						TagsFactory.add(tags, config.tags[tags]);
					}
					return tagFormatConfig(config, jax);
				},
				configPriority: 5,
				options: TagformatConfiguration.options
			});
			
			
			return MathJax.startup.defaultReady();
		}
	},
	options: {
		renderActions: {
			addMenu: []
		},
		//skipHtmlTags: ["script", "style", "textarea", "pre", "code"],// their contents aren't scanned
		//includeHtmlTags: {br: '\n', wbr: '', '#comment': ''},		// HTML tags that can appear within math
	},
	tex: {
		packages: {'[+]': ['tagFormat','color','boldsymbol','enclose','cancel','mhchem','action','html']},
		
		inlineMath: [ ["$","$"] ],		// ["$","$"],["\$","\$"],["\(","\)"],["\\(","\\)"]
		displayMath: [ ["$$","$$"] ],
		processEscapes: true,			// for \$ to mean a common dollar sign, not a math delimiter
		
		digits: /^(?:[\d۰-۹]+(?:[,٬'][\d۰-۹]{3})*(?:[\.\/٫][\d۰-۹]*)?|[\.\/٫][\d۰-۹]+)/,	// introduce numbers
		
		tagSide: "right",
		tagIndent: ".8em",
		multlineWidth: "85%",
		tags: "ams",
		tagFormat: {
			number: function(n){
				return String(n).replace(/0/g,"۰").replace(/1/g,"۱").replace(/2/g,"۲").replace(/3/g,"۳")
								.replace(/4/g,"۴").replace(/5/g,"۵").replace(/6/g,"۶")
								.replace(/7/g,"۷").replace(/8/g,"۸").replace(/9/g,"۹");
			}
		}
	},
	svg: {
		fontCache: 'global',		// or 'local' or 'none'
		mtextInheritFont: true,		// required to correctly render RTL Persian text inside a formula
		
		//scale: 0.97,				// global scaling factor for all expressions
		//minScale: 0.6				// smallest scaling factor to use
		//matchFontHeight: true,		// true to match ex-height of surrounding font
		//exFactor: .5,				// default size of ex in em units
		
		//displayAlign: 'center',		// default for indentalign when set to 'auto'
		//displayIndent: '0'			// default for indentshift when set to 'auto'
	}/*,
	chtml: {
		mtextInheritFont: true,		// required to correctly render RTL Persian text inside a formula
		
		//scale: 0.97,				// global scaling factor for all expressions
		//minScale: 0.6				// smallest scaling factor to use
		//matchFontHeight: true,		// true to match ex-height of surrounding font
		//exFactor: .5,				// default size of ex in em units
		
		//displayAlign: 'center',		// default for indentalign when set to 'auto'
		//displayIndent: '0',			// default for indentshift when set to 'auto'
		//adaptiveCSS: true			// true means only produce CSS that is used in the processed equations
	}*/
};
